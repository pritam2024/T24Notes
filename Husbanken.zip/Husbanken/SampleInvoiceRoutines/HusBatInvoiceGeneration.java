package com.husbanken.loanmain.invoices;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;
import java.util.logging.FileHandler;
import java.util.logging.SimpleFormatter;
import java.io.IOException;

import com.ibm.icu.math.BigDecimal;
import com.temenos.api.TField;
import com.temenos.api.TStructure;
import com.temenos.api.exceptions.T24IOException;
import com.temenos.t24.api.arrangement.accounting.Contract;
import com.temenos.t24.api.complex.aa.contractapi.BalanceMovement;
import com.temenos.t24.api.complex.eb.servicehook.ServiceData;
import com.temenos.t24.api.complex.eb.servicehook.TransactionData;
import com.temenos.t24.api.hook.system.ServiceLifecycle;
import com.temenos.t24.api.records.aaaccountdetails.AaAccountDetailsRecord;
import com.temenos.t24.api.records.aaarrangement.AaArrangementRecord;
import com.temenos.t24.api.records.aaarrangement.CustomerClass;
import com.temenos.t24.api.records.aaarrangementactivity.AaArrangementActivityRecord;
import com.temenos.t24.api.records.aaarrangementactivity.FieldNameClass;
import com.temenos.t24.api.records.aaarrangementactivity.PropertyClass;
import com.temenos.t24.api.records.aabilldetails.AaBillDetailsRecord;
import com.temenos.t24.api.records.aaproduct.AaProductRecord;
import com.temenos.t24.api.records.aaproperty.AaPropertyRecord;
import com.temenos.t24.api.records.customer.CustomerRecord;
import com.temenos.t24.api.records.customer.AddressClass;
import com.temenos.t24.api.records.dates.DatesRecord;
import com.temenos.t24.api.records.deaddress.DeAddressRecord;
import com.temenos.t24.api.system.DataAccess;
import com.temenos.t24.api.system.Session;
import com.temenos.t24.api.tables.ebhbinvoicedetails.ArrangementIdClass;
import com.temenos.t24.api.tables.ebhbinvoicedetails.CustomerIdClass;
import com.temenos.t24.api.tables.ebhbinvoicedetails.EbHbInvoiceDetailsRecord;
import com.temenos.t24.api.tables.ebhbinvoicedetails.LineIdClass;
import com.temenos.t24.api.tables.ebhbinvoiceleftover.EbHbInvoiceLeftoverRecord;
import com.temenos.t24.api.tables.ebhbinvoiceleftover.InvoiceIdClass;
import com.temenos.t24.api.tables.ebhbinvoiceparam.EbHbInvoiceParamRecord;
import com.temenos.t24.api.tables.ebhbinvoiceparam.FeeChannelClass;
import com.temenos.t24.api.tables.ebhbinvoiceparam.InvMinAmountCcyClass;
import com.temenos.t24.api.tables.ebhbinvoicestaging.ChargeIndicatorClass;
import com.temenos.t24.api.tables.ebhbinvoicestaging.EbHbInvoiceStagingRecord;
import com.temenos.t24.api.tables.ebhbinvoicestaging.LIdClass;
import com.temenos.t24.api.tables.ebhbinvoicestaging.PaymentMeansCodeClass;
import com.temenos.t24.api.tables.ebhbinvoicestaging.TaxAmountClass;
import com.temenos.t24.api.tables.ebhbinvoicestaging.TaxSubtotAmtClass;
import com.temenos.t24.api.tables.ebhbinvoiceunprocess.EbHbInvoiceUnprocessTable;
import com.temenos.t24.api.tables.ebhuslacase.EbHusLaCaseRecord;
import com.temenos.t24.api.tables.ebhuslacase.ProjectPartyClass;


/**
 * Routine will select records of EB.HB.INVOICE.DETAILS and will update
 * EB.HB.INVOICE.STAGING to generate invoice. Attached as : Batch routine
 * Attached to : BATCH>BNK/HUS.B.INVOICE.GENERATION
 * 
 * @author IN-L0110
 */
public class HusBatInvoiceGeneration extends ServiceLifecycle {
    private static final String ofsSrc = "HUS.LOAN.GT";
    private static final String function = "INPUT";

    String deAddressAPId = "";
    String deAddrPurpose ="";
    String cusAddress1 = "";
    String cusAddressCntry ="";
    List<String> deAddressIds =null;
    List<String> custAddList = new ArrayList<>();
    String deAddressId ="";
    List<String> lstdeAddressPurpose = new ArrayList<>();
    List<String> lstdeAddressPurposeId = new ArrayList<>();
    Logger logger = Logger.getLogger("Invoice Generation process");
    @Override
    public List<String> getIds(ServiceData serviceData, List<String> controlList) {
        try {

            FileHandler fileHandler = new FileHandler("../../../../../srv/Temenos/TAFJ/log/InvoiceGenGetIdsLog.txt");
            logger.addHandler(fileHandler);
            SimpleFormatter formatter = new SimpleFormatter();
            fileHandler.setFormatter(formatter);
        } catch (SecurityException e ) {

        } catch (IOException e) {
        }
        DataAccess da = new DataAccess(this);
        List<String> lstInvUnprocess = null;
        lstInvUnprocess = da.selectRecords("BNK", "EB.HB.INVOICE.UNPROCESS", "", "");
        logger.info("lstInvUnprocess :"+" "+lstInvUnprocess);
        return lstInvUnprocess;
    }


    @SuppressWarnings("null")
    @Override
    public void postUpdateRequest(String id, ServiceData serviceData, String controlItem,
            List<TransactionData> transactionData, List<TStructure> records) {
        try {

            FileHandler fileHandler = new FileHandler("../../../../../srv/Temenos/TAFJ/log/InvoiceGenGetIdsLog.txt");
            logger.addHandler(fileHandler);
            SimpleFormatter formatter = new SimpleFormatter();
            fileHandler.setFormatter(formatter);
        } catch (SecurityException e ) {

        } catch (IOException e) {
        }

        DataAccess da = new DataAccess(this);
        String idType = id.substring(0, 1);
        String deAddressId = null;
        String detsCustData = null;
        int lstCustdetsCnt = 0;
        int amtFlag = 0;
        List<TField> invTNote = null;
        String invNote= "";


        List<String> lstDetsAllBillIds = new ArrayList<>();
        List<String> lstDetsInvFeeAmt = new ArrayList<>();
        List<String> lstDetsChrgCost = new ArrayList<>();
        List<String> lstCustdets = new ArrayList<>();
        List<String> lstdetsVArrId = new ArrayList<>();
        ArrayList<String> lstAmntType = new ArrayList<>();
        int invArrPos =0;
        int invLinepos =0;


        String aaBillDetails = "AA.BILL.DETAILS";
        String deAddrAppName = "DE.ADDRESS";
        EbHbInvoiceUnprocessTable invUnprocess = new EbHbInvoiceUnprocessTable(this);

        // ************* Today Value ***********
        Session sess = new Session(this);
        String companyId = sess.getCompanyId();
        DatesRecord datesRec = new DatesRecord(da.getRecord("DATES", companyId));
        String highMatDate = datesRec.getToday().getValue();
        String invoiceFee = "N";

        // ******* data from EB.HB.INVOICE.DETAILS record ********
        EbHbInvoiceDetailsRecord invDetsRec = new EbHbInvoiceDetailsRecord(da.getRecord("EB.HB.INVOICE.DETAILS", id));
        LineIdClass invDetsLineId = new LineIdClass();
        ArrangementIdClass invDetsArrId = new ArrangementIdClass();

        String invDetsType = invDetsRec.getType().getValue();
        String detsChannel = invDetsRec.getChannel().getValue();
        String detsCaseId = invDetsRec.getCaseId().getValue();
        String detsInvNo = invDetsRec.getInvoiceNo().getValue();
        String detsKidNo = invDetsRec.getKidNumber().getValue();
        String detsPaymntChannel = invDetsRec.getPaymentChannel().getValue();
        String detsCustomerType = invDetsRec.getCustomerType().getValue();
        logger.info("detsCustomerType :"+" "+detsCustomerType);
        logger.info("Getting Arr id :");
        List<ArrangementIdClass> lstdetsArrIds = invDetsRec.getArrangementId();
        logger.info("lstdetsArrIds :"+" "+lstdetsArrIds);
        int lstdetsArrIdsCnt = lstdetsArrIds.size();
        logger.info("lstdetsArrIdsCnt :"+" "+lstdetsArrIdsCnt);
        for(int detsArrIds =0 ;detsArrIds< lstdetsArrIdsCnt;detsArrIds++){
            String detsArrId = lstdetsArrIds.get(detsArrIds).getArrangementId().getValue();

            logger.info("detsArrId :"+" "+detsArrId);
            if(!detsArrId.equals("")){
                lstdetsVArrId.add(detsArrId);
            }
        }
        int lstdetsVArrIdsCnt = lstdetsVArrId.size();
        BigDecimal detsTotAmt = new BigDecimal("0");
        if (!invDetsRec.getTotalAmount().getValue().equals("")) {
            detsTotAmt = new BigDecimal(invDetsRec.getTotalAmount().getValue());
            logger.info("inside loop detsTotAmt :"+" "+detsTotAmt);
        }
        String detsCcy = invDetsRec.getCurrency().getValue();
        BigDecimal pInvMinAmt = new BigDecimal("0");
        String invoiceArrId = null;
        String coCode = null;
        String sCusId = null;

        // ******get the value of last multivalue set line ID field ********
        logger.info("before lstLineId :");
        List<LineIdClass> lstLineId = invDetsRec.getArrangementId(lstdetsArrIdsCnt - 1).getLineId();
        logger.info("lstLineId :"+" "+lstLineId);
        int lstLineIdCnt = lstLineId.size();
        logger.info("lstLineIdCnt :"+" "+lstLineIdCnt);
        int lastLineValue = 0;
        int orgLineVal=0;
        logger.info("before lstLine :");
        String lstLine = lstLineId.get(lstLineIdCnt - 1).getLineId().toString();
        logger.info("lstLine :"+" "+lstLine);
        if (lstLine != null) {
            lastLineValue = Integer.parseInt(lstLineId.get(lstLineIdCnt - 1).getLineId().toString());
            orgLineVal = lastLineValue;
            logger.info("inside lastLineValue :"+" "+lastLineValue);
            logger.info("orgLineVal :"+" "+orgLineVal);
        }

        //get Customer Class details
        List<CustomerIdClass> lstInvDetsCustClass = invDetsRec.getCustomerId();
        int lstInvDetsCustClassCnt = lstInvDetsCustClass.size();
        lstCustdets = new ArrayList<>();
        lstCustdetsCnt = 0;
        detsCustData = null;
        for(int totcustDetsCnt = 0;totcustDetsCnt < lstInvDetsCustClassCnt ; totcustDetsCnt++){
            String custId = lstInvDetsCustClass.get(totcustDetsCnt).getCustomerId().getValue();
            String RegId =lstInvDetsCustClass.get(totcustDetsCnt).getRegisterId().getValue();
            String DbtStatus = lstInvDetsCustClass.get(totcustDetsCnt).getDbtRestStatus().getValue();

            detsCustData = custId + "*" + RegId + "*" + DbtStatus;
            logger.info("detsCustData :"+" "+detsCustData);
            try {
                lstCustdets.add(detsCustData);
            }
            catch (Exception e) {
                Logger.getLogger(e.getMessage()); 
            }
        }
        lstCustdetsCnt = lstCustdets.size();
        logger.info("lstCustdetsCnt :"+" "+lstCustdetsCnt);
        // *******data from EB.HB.INVOICE.PARAM record****
        EbHbInvoiceParamRecord invParamRec = new EbHbInvoiceParamRecord(da.getRecord("EB.HB.INVOICE.PARAM", "SYSTEM"));
        List<FeeChannelClass> lstparamChannel = invParamRec.getFeeChannel();
        int paramChannelCnt = lstparamChannel.size();
        logger.info("paramChannelCnt :"+" "+paramChannelCnt);
        List<InvMinAmountCcyClass> lstInvMinAmt = invParamRec.getInvMinAmountCcy();
        logger.info("lstInvMinAmt :"+" "+lstInvMinAmt);
        int lstInvMinAmtCnt = lstInvMinAmt.size();
        logger.info("lstInvMinAmtCnt :"+" "+lstInvMinAmtCnt);
        String pChrgDesc = invParamRec.getChargeDesc().getValue();
        String pCostDesc = invParamRec.getCostDesc().getValue();


        // Check for invoice details currency in invoice param and get
        // corresponding invoice minimum amount
        for (int i = 0; i < lstInvMinAmtCnt; i++) {
            String invParamCcy = lstInvMinAmt.get(i).getInvMinAmountCcy().getValue();
            logger.info("invParamCcy :"+" "+invParamCcy);
            BigDecimal invParamMinAmt = new BigDecimal("0");
            String invminAmount = lstInvMinAmt.get(i).getInvMinAmount().getValue();
            if(!invminAmount.equals("")){
                //  invParamMinAmt = Double.parseDouble(lstInvMinAmt.get(i).getInvMinAmount().getValue());
                invParamMinAmt = new BigDecimal(invminAmount);
                logger.info("invParamMinAmt :"+" "+invParamMinAmt);
            }
            //            if (!lstInvMinAmt.get(i).getInvMinAmount().getValue().equals("")) {
            //                invParamMinAmt = Double.parseDouble(lstInvMinAmt.get(i).getInvMinAmount().getValue());
            //            }
            if (invParamCcy.equals(detsCcy)) {
                pInvMinAmt = invParamMinAmt;
                logger.info(" pInvMinAmt :"+" "+ pInvMinAmt);
            }
        }

        // ******get all bill ids in INVOICE.DETAILS and data from INVOICE.PARAM
        // **********
        String detsBillId = null;
        int invFeeFlag = 0;
        int invFeeCC = 0;
        String detsArrId = null;
        String aaProductDesc = null;
        BigDecimal reminderFeeAmt = new BigDecimal("0");
        BigDecimal currBalance =new BigDecimal("0");
        BigDecimal uncBal = new BigDecimal("0");
        logger.info(" get all bill ids in INVOICE.DETAILS :");
        String aaActDetsMatDate = null;
        for (int m = 0; m < lstdetsVArrIdsCnt; m++) {
            List<LineIdClass> lstDetsBillId = invDetsRec.getArrangementId(m).getLineId();
            detsArrId = lstdetsVArrId.get(m);
            logger.info(" detsArrId :"+" "+ detsArrId);
            // detsArrId =  lstdetsArrIds.get(m).getArrangementId().getValue();
            AaArrangementRecord aarec = new AaArrangementRecord(da.getRecord("AA.ARRANGEMENT", detsArrId));
            //Sum of UNC Account
            Contract contractRec = new Contract(this);
            contractRec.setContractId(detsArrId); // Current Arrangement ID
            try {
                List<BalanceMovement> lstBalMovements = contractRec.getContractBalanceMovements("UNCACCOUNT", "BOOKING");
                //String to number conversion
                String getBalMvmnt = lstBalMovements.get(0).getBalance().toString();
                if(!getBalMvmnt.equals("")) {
                    currBalance = new BigDecimal(getBalMvmnt);
                    logger.info(" currBalance :"+" "+ currBalance);
                }
            } catch (Exception e) {
                Logger.getLogger(e.getMessage());
            }
            uncBal = uncBal.add(currBalance);
            logger.info("  uncBal :"+" "+  uncBal);
            //**********

            AaAccountDetailsRecord aaActDets = new AaAccountDetailsRecord(da.getRecord("AA.ACCOUNT.DETAILS", detsArrId));
            aaActDetsMatDate = aaActDets.getMaturityDate().getValue();
            String prdGroup = aarec.getProductGroup().getValue();
            String aaProductId = aarec.getProduct(0).getProduct().getValue();
            AaProductRecord aaProductRec = new AaProductRecord(da.getRecord("AA.PRODUCT", aaProductId));
            aaProductDesc = aaProductRec.getDescription(0).getValue();
            coCode = aarec.getCoCodeRec().toString();
            if (prdGroup.equals("HUS.MORTGAGES") && (aaActDetsMatDate.compareTo(highMatDate) >= 0)) {
                highMatDate = aaActDetsMatDate;
                invoiceFee = "Y";
                invoiceArrId = detsArrId;
                logger.info("  highMatDate :"+" "+  highMatDate);
                logger.info("  invoiceFee :"+" "+  invoiceFee);
                logger.info("  invoiceArrId :"+" "+  invoiceArrId);

            }

            // ************data required for updating bill details in
            // staging***********
            int lstDetsBillIdCnt = lstDetsBillId.size();
            BigDecimal detsInvFeeAmt = new BigDecimal("0");
            logger.info("data required for updating bill details - lstDetsBillIdCnt :"+" "+  lstDetsBillIdCnt);
            for (int n = 0; n < lstDetsBillIdCnt; n++) {
                String aaPropDesc = "";               
                detsBillId = lstDetsBillId.get(n).getBillId().getValue();
                logger.info("  detsBillId :"+" "+  detsBillId);
                String detsInvFeeAmtType = lstDetsBillId.get(n).getAmountType().getValue();

                //String to number conversion
                String InvFeeAmt = lstDetsBillId.get(n).getAmount().getValue();     
                if(!InvFeeAmt.equals("")) {
                    detsInvFeeAmt = new BigDecimal(InvFeeAmt);
                }
                try {
                    AaBillDetailsRecord aaBillDetsRec = new AaBillDetailsRecord(
                            da.getRecord(aaBillDetails, detsBillId));
                    String billProp = aaBillDetsRec.getProperty(0).getProperty().getValue();
                    AaPropertyRecord aaPropRec = new AaPropertyRecord(da.getRecord("AA.PROPERTY", billProp));
                    aaPropDesc = aaPropRec.getDescription(0).getValue();
                } catch(Exception e) {}

                if (detsInvFeeAmtType.equals("REMINDERFEE")) {
                    reminderFeeAmt = reminderFeeAmt.add(detsInvFeeAmt);
                    logger.info("  reminderFeeAmt :"+" "+ reminderFeeAmt);
                }

                if (detsInvFeeAmtType.equals("INVOICEFEE")) {
                    lstDetsInvFeeAmt.add(String.valueOf(detsInvFeeAmt));
                    invFeeFlag = 1;
                    logger.info(" INVOICEFEE rdetsInvFeeAmt :"+" "+ detsInvFeeAmt);
                }
                if ((detsInvFeeAmtType.equals("CHARGE")) || (detsInvFeeAmtType.equals("COST"))) {
                    if (detsInvFeeAmtType.equals("CHARGE")) {
                        aaProductDesc = aaProductDesc + "-" + pChrgDesc;
                    } else {
                        aaProductDesc = aaProductDesc + "-" + pCostDesc;
                    }
                    String detsChrgCost = detsArrId + "*" + detsInvFeeAmt + "*" + aaPropDesc + "*" + aaProductDesc;
                    lstDetsChrgCost.add(detsChrgCost);
                    invFeeCC = 1;
                    logger.info("  aaProductDesc :"+" "+ aaProductDesc);
                }

                lstDetsAllBillIds.add(detsBillId);
                logger.info("  detsBillId :"+" "+ detsBillId);

            }

        }
        int invFeeCnt = lstDetsInvFeeAmt.size();
        int invChrgCnt = lstDetsChrgCost.size();

        //Prepaid Amount calculation
        BigDecimal sPrepaidAmt = new BigDecimal("0");
        if(uncBal.compareTo(detsTotAmt)>=0){
            sPrepaidAmt = detsTotAmt; 
        }else{
            sPrepaidAmt = uncBal;
        }
        BigDecimal payableAmt =  new BigDecimal("0");
        payableAmt = detsTotAmt.subtract(sPrepaidAmt);
        logger.info("  payableAmt :"+" "+ payableAmt);
        // *********data from EB.HB.INVOICE.LEFTOVER record************
        int lstinvLeftOvrCnt = 0;
        List<InvoiceIdClass> lstinvLeftOvr = null;
        InvoiceIdClass lftOvrNewInv = new InvoiceIdClass();
        EbHbInvoiceLeftoverRecord invLeftOvrRec = null;
        try {
            invLeftOvrRec = new EbHbInvoiceLeftoverRecord(da.getRecord("EB.HB.INVOICE.LEFTOVER", detsCaseId));
            lstinvLeftOvr = invLeftOvrRec.getInvoiceId();
            lstinvLeftOvrCnt = lstinvLeftOvr.size();
            logger.info("  lstinvLeftOvr :"+" "+ lstinvLeftOvr);

        } catch (Exception e) {
            Logger.getLogger(e.getMessage());
        }

        // ***************classes from EB.HB.INVOICE.STAGING record**********
        EbHbInvoiceStagingRecord invStagingRec = new EbHbInvoiceStagingRecord();
        CustomerIdClass stagingCustId = new CustomerIdClass();
        ChargeIndicatorClass stagingChrgInd = new ChargeIndicatorClass();
        LIdClass stagingLID = new LIdClass();
        PaymentMeansCodeClass stagingPayMCode = new PaymentMeansCodeClass();
        TaxAmountClass stagingTaxAmt = new TaxAmountClass();
        TaxSubtotAmtClass stagingSubTot = new TaxSubtotAmtClass();
        com.temenos.t24.api.tables.ebhbinvoicestaging.CustomerIdClass stagingCust = new com.temenos.t24.api.tables.ebhbinvoicestaging.CustomerIdClass();
        logger.info(" Data required from INVOICE.DETAILS & INVOICE.PARAM to update STAGING:");
        // *****Data required from INVOICE.DETAILS & INVOICE.PARAM to update
        // INVOICE.STAGING*******

        List<TField> sTCustomisation = null;
        String sCustomisation = "";
        List<TField> sTProfileId = null;
        String sProfileId = "";


        String sTypeCode = null;      
        String sCompId = invParamRec.getCompanyId().getValue();
        String sSchemeId = invParamRec.getSchemeId().getValue();
        String sAddName = invParamRec.getAddName().getValue();
        String sAddStreet = invParamRec.getAddStreet().getValue();
        String sAddTown = invParamRec.getAddTown().getValue();
        String addPostCode = invParamRec.getAddPostCode().getValue();
        String sAddCountry = invParamRec.getAddCountry().getValue();
        String sDDMeansCode = invParamRec.getDirectDebitMeansCode().getValue();
        String sPaymentMeansCode = invParamRec.getPaymentMeansCode().getValue();
        String sBnkCode = invParamRec.getBankAccount().getValue();
        String sInvFeeDesc = invParamRec.getInvoiceFeeDesc().getValue();
        String sInvCrNote = invParamRec.getCrNoteTypeCode().getValue();
        String pTaxCateg = invParamRec.getTaxCategory().getValue();
        String pUnitCode = invParamRec.getUnitCode().getValue();

        String sInvIssueDate = invDetsRec.getIssueDate().getValue();
        String sInvDueDate = invDetsRec.getDueDate().getValue();
        String sInvCcy = invDetsRec.getCurrency().getValue();
        String sInvCustRef = invDetsRec.getCustomerRef().getValue();

        String sInvChrgIndicator = "true";
        String sInvChrgRsnCode = "IS";
        String sInvChrgTaxCode = "O";
        String sInvChrgTaxSchemeId = "VAT";
        String sTaxAmt = "0";
        String sInvTaxCateg = "O";
        String sTaxExmpCode = "VATEX-EU-O";
        String sTaxSchemeId = "VAT";
        String sLInvQuantity = "1";
        String sLDocSchemeId = "ADC";
        String sLDocCodeType = "130";

        String sInvPaymntChannel = null;

        if (detsPaymntChannel.equals("DIRECT.DEBIT")) {
            sInvPaymntChannel = sDDMeansCode;
        } else {
            sInvPaymntChannel = sPaymentMeansCode;
        }

        logger.info(" sInvPaymntChannel :"+" "+  sInvPaymntChannel);

        // *********************DE.ADDRESS***************
        int flag = 0;
        String  sRegId = null;
        CustomerRecord cusRec =new CustomerRecord();
        CustomerRecord cusRecVal =null;
        try {
            sCusId = invDetsRec.getCustomerId().get(0).getCustomerId().toString();
            cusRecVal = customerDetails(cusRec,da,sCusId,custAddList); // Organisation
            if(!cusRecVal.equals("")){
                sRegId = cusRecVal.getLocalRefField("HUS.REGISTER.ID").getValue(); 
            }

            logger.info("  sRegId :"+" "+   sRegId);
            logger.info("   sCusId :"+" "+   sCusId);
        } catch (Exception e) {
            Logger.getLogger(e.getMessage());
        }

        String sDeAddrStrtAddr = "";
        String sDeAddrName = "";
        String sDeAddrTownCountry = "";
        String sDeAddrPostCode = "";
        String sDeAddrCountry = "";
        String sDeAddrStrtName ="";
        String sDeAddrCntryCode ="";
        DeAddressRecord deAddressRec = new DeAddressRecord();
        DeAddressRecord address =null;

        try {
            address =deAddressProjectParty(sCusId,deAddressRec,da);

            try{
                sDeAddrStrtAddr = address.getStreetAddr(0).getValue();
            } catch (Exception e) {               
            }
            try{
                sDeAddrName = address.getName1(0).getValue();
            } catch (Exception e) {
            }
            try{
                sDeAddrTownCountry = address.getTownCountry(0).getValue();
            } catch (Exception e) {

            }
            try{
                sDeAddrPostCode = address.getPostCode(0).getValue();
            } catch (Exception e) {

            }
            try{
                sDeAddrCountry = address.getCountry(0).getValue();

            } catch (Exception e) {

            }
            //Update country code
            if(sDeAddrCountry.equals("")) {
                sDeAddrCountry ="NO"; 
            }
            try{
                sDeAddrStrtName = custAddList.get(0).toString();

            } catch (Exception e) {

            }
            try{
                sDeAddrCntryCode = custAddList.get(1).toString();

            } catch (Exception e) {

            }

            custAddList.removeAll(custAddList);

        } catch (Exception e) {
            Logger.getLogger(e.getMessage());
        }


        // ***********************************If INVOICE.TYPE equals
        // I***************************************
        List<String> listpParty = new ArrayList<>();
        List<String> listpRole = new ArrayList<>();
        List<String> listCusAddr = new ArrayList<>();
        int  adoptedCnt=0;
        int negotiationCnt=0;
        int partyCnt=0;
        int custBorrCnt = 0;
        int nFlag=0;
        int aFlag=0;
        String nDeAddrStrtAddr = "";
        String nDeAddrName ="";
        String nDeAddrTownCountry ="";
        String nDeAddrPostCode ="";
        String nDeAddrCountry ="";
        String  nDeAddrStrtName ="";
        try{
            EbHusLaCaseRecord lacaseRec = new EbHusLaCaseRecord(da.getRecord("EB.HUS.LA.CASE", detsCaseId));
            String pRole = "";
            partyCnt = lacaseRec.getProjectParty().size();
            logger.info("partyCnt"+ " "+partyCnt);
            for(int i =0;i<partyCnt ;i++){
                String projParty = "";
                String partyRole = "";                           

                projParty = lacaseRec.getProjectParty(i).getProjectParty().toString();
                try{
                    partyRole = lacaseRec.getProjectParty(i).getPartyRole().toString();
                }catch(Exception e){}
                if(partyRole.equals("BORROWER")){                              
                    listpRole.add(projParty);
                    sCusId = projParty;
                    customerDetails(cusRec,da,sCusId,custAddList);
                    logger.info("cusRec"+ " "+cusRec);
                    address = deAddressProjectParty(sCusId,deAddressRec,da);
                    logger.info("address"+ " "+address);
                    if(!address.equals(null)){
                        logger.info("Indise if loop");
                        try{
                            nDeAddrStrtAddr = address.getStreetAddr(0).getValue();
                        } catch (Exception e) {               
                        }
                        try{
                            nDeAddrName = address.getName1(0).getValue();
                        } catch (Exception e) {
                        }
                        try{
                            nDeAddrTownCountry = address.getTownCountry(0).getValue();
                        } catch (Exception e) {

                        }
                        try{
                            nDeAddrPostCode = address.getPostCode(0).getValue();
                        } catch (Exception e) {

                        }
                        try{
                            nDeAddrCountry = custAddList.get(1).toString();
                        } catch(Exception e){}
                        try{
                            nDeAddrStrtName = custAddList.get(0).toString();
                        } catch(Exception e){}

                        String cusParty  = nDeAddrName+","+nDeAddrStrtAddr +","+ nDeAddrStrtName+","+nDeAddrTownCountry+","+nDeAddrPostCode+","+nDeAddrCountry;
                        listpParty.add(cusParty);
                        logger.info("cusParty"+ " "+cusParty);
                        logger.info("listpParty"+ " "+listpParty);
                        if(!listpParty.isEmpty()){
                            pRole = String.join("&", listpParty);
                        }
                    }
                    custAddList.removeAll(custAddList);
                    logger.info("Outside if loop");
                    logger.info("pRole"+ " "+pRole);
                    logger.info("custAddList"+ " "+custAddList);
                }
            }
            if(!pRole.equals("")) {
                if (idType.equals("I")){
                    try{
                        invTNote = invParamRec.getNoteInvoice();
                        invNote =  invParamRec.getNoteInvoice().get(0).toString()+ "#" + pRole;
                        logger.info("I invNote"+ " "+invNote);
                    }catch(Exception e){
                    }
                }
                else if (idType.equals("P")){
                    try{
                        invNote = invParamRec.getNotePaymentRequest().get(0).toString()+ "#" + pRole;
                        logger.info("P invNote"+ " "+invNote);
                    }catch(Exception e){
                    }
                }
            } else{
                if (idType.equals("I")){
                    try{
                        invTNote = invParamRec.getNoteInvoice();
                        invNote =  invParamRec.getNoteInvoice().get(0).toString();
                        logger.info("I2 invNote"+ " "+invNote);
                    }catch(Exception e){
                    }

                }
                else if (idType.equals("P")){
                    try{
                        invNote = invParamRec.getNotePaymentRequest().get(0).toString();
                        logger.info("P2 invNote"+ " "+invNote);
                    }catch(Exception e){
                    }
                }
            }

        }catch(Exception e){
        }
        //checking customer debtReststatus as negotiation or adopted
        custBorrCnt =listpRole.size();
        for(int custBorr=0;custBorr<custBorrCnt;custBorr++){
            String party = listpRole.get(custBorr);
            CustomerRecord cusRec2 = new CustomerRecord(da.getRecord("CUSTOMER", party)); 
            String dbtRestStatus = cusRec2.getLocalRefField("DBT.REST.STATUS").getValue(); // Local field DBT.REST.STATUS is fetched from CUSTOMER table

            logger.info("customer record : "+cusRec2);
            logger.info("dbtRestStatus : "+dbtRestStatus);
            if (dbtRestStatus.equals("ADOPTED")) {
                adoptedCnt = adoptedCnt + 1;// Count is increased for each of the DBT.REST.STATUS value equals ADOPTED
                logger.info("adoptedCnt"+ " "+adoptedCnt);
            } else {
                if (dbtRestStatus.equals("NEGOTIATION")) {
                    negotiationCnt = negotiationCnt + 1; // Count is increased for each of the DBT.REST.STATUS value equals NEGOTIATION
                }
            }
        }

        logger.info("adoptedCnt"+ " "+adoptedCnt);
        logger.info("negotiationCnt"+ " "+negotiationCnt);
        logger.info("custBorrCnt"+ " "+custBorrCnt);

        if(custBorrCnt==negotiationCnt) {
            nFlag =1;
        }
        if(custBorrCnt==adoptedCnt) {
            aFlag=1;
        }
        if(nFlag!=1){
            String paramFeeChannel = "";
            BigDecimal paramFeeAmt = new BigDecimal("0");
            BigDecimal invoiceFeeAmt = new BigDecimal("0");
            if (idType.equals("I")) {
                if (detsTotAmt.compareTo(pInvMinAmt)>=0) {
                    logger.info(" I type ddetsTotAmt :"+" "+detsTotAmt+" "+pInvMinAmt);
                    int newLineId = 0;
                    if (invoiceFee.equals("Y")) {
                        for (int k = 0; k < paramChannelCnt; k++) {
                            try{
                                paramFeeChannel = lstparamChannel.get(k).getFeeChannel().getValue();
                            }catch(Exception e){                           
                            }
                            try{
                                paramFeeAmt = new BigDecimal(lstparamChannel.get(k).getFeeAmount().getValue());
                            }
                            catch(Exception e){                           
                            }
                            if (paramFeeChannel.equals(detsChannel)) {

                                logger.info("before transactionData :"+" "+transactionData);
                                logger.info("records :"+" "+records);
                                logger.info("invoiceArrId :"+" "+invoiceArrId);
                                logger.info("coCode :"+" "+coCode);
                                logger.info("invoiceFeeAmt) :"+" "+invoiceFeeAmt);
                                if(aFlag!=1)
                                {
                                    if(invFeeFlag!=1)
                                    {
                                        invoiceFeeAmt = paramFeeAmt;

                                        genLendingChrgAct(transactionData, records,
                                                invoiceArrId, coCode, invoiceFeeAmt,id);
                                        logger.info("after transactionData :"+" "+transactionData);
                                        logger.info("records :"+" "+records);
                                        logger.info("invoiceArrId :"+" "+invoiceArrId);
                                        logger.info("coCode :"+" "+coCode);
                                        logger.info("invoiceFeeAmt) :"+" "+invoiceFeeAmt);
                                        invDetsLineId = new LineIdClass();
                                        List<String> arrList = new ArrayList<>(lstdetsVArrId);
                                        invArrPos = arrList.indexOf(invoiceArrId);
                                        List<LineIdClass> invDetsBillId = invDetsRec.getArrangementId(invArrPos).getLineId();
                                        int lineIdCnt =invDetsBillId.size();

                                        String invLineId = invDetsBillId.get(lineIdCnt-1).getLineId().toString();
                                        int invoiceLine = Integer.parseInt(invLineId);
                                        invLinepos = invoiceLine+1;
                                        invDetsLineId.setLineId(String.valueOf(invLinepos));
                                        invDetsLineId.setAmountType("INVOICEFEE");
                                        invDetsLineId.setAmount(invoiceFeeAmt.toString());   //Converting BigDecimal to String
                                        invDetsArrId.setLineId(invDetsLineId, lineIdCnt);
                                        lastLineValue = lastLineValue+1;
                                        logger.info("invoiceLine"+" "+invoiceLine);
                                        logger.info("invLinepos"+" "+invLinepos);
                                        logger.info("lineIdCnt"+" "+lineIdCnt);
                                        logger.info("invArrPos"+" "+invArrPos);
                                        logger.info("invDetsArrId"+" "+invDetsArrId);
                                        invDetsRec.setArrangementId(invDetsArrId, invArrPos);
                                    }
                                }
                                if(!invoiceFeeAmt.equals("")){
                                    detsTotAmt =  detsTotAmt.add(invoiceFeeAmt);
                                } 

                            }

                        }
                    }
                    newLineId = 0;
                    BigDecimal osAmt = new BigDecimal("0");
                    BigDecimal newInvDetsAmt = new BigDecimal("0");
                    BigDecimal sNewInvDetsAmt = new BigDecimal("0");
                    BigDecimal mNewInvDetsAmt = new BigDecimal("0");

                    for (int l = 0; l < lstinvLeftOvrCnt; l++) {
                        logger.info("Inside leftOver loop :");
                        String invLONewInv = lstinvLeftOvr.get(l).getNewInvoice().getValue();
                        logger.info("invLONewInv :"+" "+invLONewInv);
                        List<TField> invLOBillId = lstinvLeftOvr.get(l).getBillId();
                        logger.info("invLOBillId :"+" "+invLOBillId);
                        int billCnt = invLOBillId.size();
                        lstinvLeftOvr.get(l).getNewInvoice().setValue(id);
                        if (invLONewInv.equals("")) {
                            if ((billCnt == 1)) {
                                logger.info("billCnt :"+" "+billCnt);
                                newLineId = lastLineValue + 1;
                                String aaBillId = invLOBillId.get(0).getValue();
                                try {
                                    AaBillDetailsRecord aaBillDetsRec = new AaBillDetailsRecord(
                                            da.getRecord(aaBillDetails, aaBillId));
                                    if (!aaBillDetsRec.getOsTotalAmount().getValue().equals("")) {
                                        osAmt = new BigDecimal(aaBillDetsRec.getOsTotalAmount().getValue());
                                        logger.info(" osAmt :"+" "+ osAmt );
                                    }
                                    sNewInvDetsAmt = sNewInvDetsAmt.add(osAmt);
                                } catch(Exception e) {}
                                invDetsArrId = new ArrangementIdClass();
                                invDetsLineId = new LineIdClass();
                                invDetsArrId.setArrangementId("");
                                invDetsLineId.setLineId(String.valueOf(newLineId));
                                invDetsLineId.setBillId("");
                                invDetsLineId.setAmountType("");
                                invDetsLineId.setAmount(osAmt.toString());
                                invDetsArrId.addLineId(invDetsLineId);
                                invDetsRec.addArrangementId(invDetsArrId);
                                lastLineValue = newLineId;
                                lstdetsArrIdsCnt++;

                            } else {
                                logger.info("billCnt NE 1 :");
                                for (int m = 0; m < billCnt; m++) {
                                    newLineId = lastLineValue + 1;
                                    String aaBillId = invLOBillId.get(m).getValue();
                                    try {
                                        AaBillDetailsRecord aaBillDetsRec = new AaBillDetailsRecord(
                                                da.getRecord(aaBillDetails, aaBillId));
                                        if (!aaBillDetsRec.getOsTotalAmount().getValue().equals("")) {
                                            osAmt = new BigDecimal(aaBillDetsRec.getOsTotalAmount().getValue());
                                            logger.info(" osAmt :"+" "+ osAmt );
                                        }
                                        mNewInvDetsAmt = mNewInvDetsAmt.add(osAmt);
                                    } catch (Exception e ) {}
                                    invDetsArrId = new ArrangementIdClass();
                                    invDetsLineId = new LineIdClass();
                                    invDetsArrId.setArrangementId("");
                                    invDetsLineId.setLineId(String.valueOf(newLineId));
                                    invDetsLineId.setBillId("");
                                    invDetsLineId.setAmountType("");
                                    invDetsLineId.setAmount(osAmt.toString());
                                    invDetsRec.addArrangementId(invDetsArrId);
                                    invDetsArrId.addLineId(invDetsLineId);
                                    lastLineValue = newLineId;
                                    lstdetsArrIdsCnt++;

                                }
                            } // 
                        }

                    }
                    if(orgLineVal!=lastLineValue){

                        int newInvLine = invLinepos;
                        for(int arrCnt =invArrPos+1;arrCnt<lstdetsArrIdsCnt;arrCnt++) {
                            ArrangementIdClass arrangementRec = new ArrangementIdClass();
                            List<LineIdClass> setInvIdLst = lstdetsArrIds.get(arrCnt).getLineId();
                            int lineIdCnt = setInvIdLst.size();
                            for(int invCnt=0;invCnt<lineIdCnt;invCnt++){
                                LineIdClass lineIdRec = new LineIdClass();
                                int linePos = newInvLine+1;
                                lineIdRec.setLineId(String.valueOf(linePos)); 
                                arrangementRec.setLineId(lineIdRec, invCnt);
                                newInvLine =linePos;
                            }
                            invDetsRec.setArrangementId(arrangementRec, arrCnt);
                        }
                    }

                    // ********update INVOICE.DETAILS &&
                    // INVOICE.LEFTOVER****************************
                    newInvDetsAmt = sNewInvDetsAmt.add(mNewInvDetsAmt);
                    newInvDetsAmt = newInvDetsAmt.add(detsTotAmt);
                    logger.info(" newInvDetsAmt :"+" "+ newInvDetsAmt );
                    invDetsRec.setTotalAmount(newInvDetsAmt.toString());
                    if(!(invDetsRec == null)){
                        updInvDetails(id, transactionData, records, invDetsRec, coCode);
                        logger.info(" updInvDetails :"+" "+ id+""+transactionData );
                    }
                    if(!(invLeftOvrRec == null)){
                        updInvoiceLeftOver(transactionData, records, detsCaseId, coCode, invLeftOvrRec);
                        logger.info(" updInvoiceLeftOver :"+" "+ detsCaseId+""+invLeftOvrRec );
                    }

                } else {
                    int detsTotBillSize = lstDetsAllBillIds.size();
                    if (detsTotBillSize > 0) {
                        lftOvrNewInv.setInvoiceId(detsKidNo);
                    }
                    for (int billCnt = 0; billCnt < detsTotBillSize; billCnt++) {
                        String billIdVal = lstDetsAllBillIds.get(billCnt);
                        lftOvrNewInv.setBillId(billIdVal, billCnt);
                    }
                    if (invLeftOvrRec == null) {
                        invLeftOvrRec = new EbHbInvoiceLeftoverRecord(this);
                        invLeftOvrRec.setInvoiceId(lftOvrNewInv, 0);
                    } else {
                        invLeftOvrRec.addInvoiceId(lftOvrNewInv);
                    }
                    if(!(invLeftOvrRec == null)){
                        updInvoiceLeftOver(transactionData, records, detsCaseId, coCode, invLeftOvrRec);
                    }
                    invDetsRec.setStatus("CLOSED");
                    if(!(invDetsRec == null)){
                        updInvDetails(id, transactionData, records, invDetsRec, coCode);
                    }
                    amtFlag = 1;

                }

            } // TYPE = I

            // ***********************************If INVOICE.TYPE equals
            // P**********************************************
            logger.info("before idType :"+" "+ idType);
            logger.info("amtFlag :"+" "+ amtFlag);
            if (((idType.equals("I")) && (amtFlag != 1)) || (idType.equals("P"))) {
                // Create new record in Staging
                logger.info("after idType :"+" "+ idType);
                logger.info("amtFlag :"+" "+ amtFlag);
                invStagingRec.setInvoiceDetailsId(id, 0);
                invStagingRec.setType(invDetsType);
                invStagingRec.setCaseId(detsCaseId);
                logger.info("invStagingRec :"+" "+ detsCaseId);
                logger.info("lstInvDetsCustClassCnt :"+" "+ lstInvDetsCustClassCnt);
                for(int lstCustCnt = 0; lstCustCnt< lstInvDetsCustClassCnt ;lstCustCnt++){
                    String sCusClsId = "";
                    String sRegClsId = "";
                    String sRstStatus = "";
                    String sCusData = "";
                    try{
                        sCusData = lstCustdets.get(lstCustCnt);
                    }catch(Exception e){}
                    try{
                        sCusClsId = sCusData.split("\\*")[0];
                    }catch(Exception e){}
                    try{
                        sRegClsId = sCusData.split("\\*")[1];
                    }catch(Exception e){}
                    try{
                        sRstStatus = sCusData.split("\\*")[2];
                    }catch(Exception e){}
                    logger.info("sCusData :"+" "+ sCusData);
                    stagingCust = new com.temenos.t24.api.tables.ebhbinvoicestaging.CustomerIdClass();
                    stagingCust.setCustomerId(sCusClsId);
                    stagingCust.setRegisterId(sRegClsId);
                    stagingCust.setDbtRestStatus(sRstStatus);
                    invStagingRec.addCustomerId(stagingCust);
                    logger.info("inside for loop invStagingRec :"+" "+sRstStatus+" "+stagingCust);
                }


                invStagingRec.setFileId(detsInvNo);
                logger.info("detsInvNo"+ " "+detsInvNo);
                invStagingRec.setIssueDate(sInvIssueDate);
                logger.info("sInvIssueDate"+ " "+sInvIssueDate);
                invStagingRec.setDueDate(sInvDueDate);
                logger.info("sInvDueDate"+ " "+sInvDueDate);
                if (idType.equals("I")) {
                    logger.info("before sTypeCode"+ " "+sTypeCode);
                    sTypeCode = invParamRec.getInvoiceTypeCode().getValue();
                    logger.info("after sTypeCode"+ " "+sTypeCode);
                } else if (idType.equals("P")) {
                    logger.info("after P sTypeCode"+ " "+sTypeCode);
                    sTypeCode = invParamRec.getPayRqstTypeCode().getValue();
                    logger.info("after P sTypeCode"+ " "+sTypeCode);
                }

                invStagingRec.setInvoiceTypeCode(sTypeCode);
                logger.info("sTypeCode"+ " "+sTypeCode);
                invStagingRec.setDocumentCurrencyCode(sInvCcy);
                logger.info("sInvCcy"+ " "+sInvCcy);
                invStagingRec.setBuyerReference(sInvCustRef);
                logger.info("sInvCustRef"+ " "+sInvCustRef);
                invStagingRec.setInvoiceDocumentRef(detsCaseId);
                logger.info("detsCaseId"+ " "+detsCaseId);
                invStagingRec.setContractDocumentRef(detsCaseId);
                logger.info("detsCaseId"+ " "+detsCaseId);

                invStagingRec.setSEndPointId(sCompId);
                logger.info("sCompId"+ " "+sCompId);
                invStagingRec.setSSchemeId(sSchemeId);
                logger.info("sSchemeId"+ " "+sSchemeId);
                invStagingRec.setSName(sAddName);
                logger.info("sAddName"+ " "+sAddName);
                invStagingRec.setSStreetName(sAddStreet);
                logger.info("sAddStreet"+ " "+sAddStreet);
                invStagingRec.setSCityName(sAddTown);
                logger.info("sAddTown"+ " "+sAddTown);
                invStagingRec.setSPostalZone(addPostCode);
                logger.info("sAddTown"+ " "+sAddTown);
                invStagingRec.setSCountryCode(sAddCountry);
                logger.info("sAddCountry"+ " "+sAddCountry);
                invStagingRec.setSRegistrationName(sAddName);
                logger.info("sAddName"+ " "+sAddName);
                invStagingRec.setSCompanyId(sCompId);
                logger.info("sCompId"+ " "+sCompId);
                invStagingRec.setSCompanySchemeId(sSchemeId);
                logger.info("sSchemeId"+ " "+sSchemeId);

                invStagingRec.setBEndPointId(sRegId);
                logger.info("sRegId"+ " "+sRegId);
                invStagingRec.setBSchemeId(sSchemeId);
                logger.info("sSchemeId"+ " "+sSchemeId);
                invStagingRec.setBName(sDeAddrName);
                logger.info("sDeAddrName"+ " "+sDeAddrName);
                invStagingRec.setBAddStreetName(sDeAddrStrtName);
                logger.info("setBAddStreetName"+ " "+sDeAddrStrtName);
                invStagingRec.setBStreetName(sDeAddrStrtAddr);
                logger.info("sDeAddrStrtAddr"+ " "+sDeAddrStrtAddr);
                invStagingRec.setBCityName(sDeAddrTownCountry);
                logger.info("sDeAddrTownCountry"+ " "+sDeAddrTownCountry);
                invStagingRec.setBPostalZone(sDeAddrPostCode);
                logger.info("sDeAddrPostCode"+ " "+sDeAddrPostCode);
                invStagingRec.setBCountrySubentity(sDeAddrCountry);
                logger.info("sDeAddrCountry"+ " "+sDeAddrCountry);
                invStagingRec.setBCountryCode(sDeAddrCntryCode);
                logger.info("setBCountryCode"+ " "+sDeAddrCntryCode);
                invStagingRec.setBRegistrationName(sDeAddrName);
                logger.info("sDeAddrName"+ " "+sDeAddrName);

                stagingPayMCode.setPaymentMeansCode(sInvPaymntChannel);
                logger.info("sInvPaymntChannel"+ " "+sInvPaymntChannel);
                stagingPayMCode.setPaymentId(detsKidNo);
                logger.info("detsKidNo"+ " "+detsKidNo);
                stagingPayMCode.setPaymentAccount(sBnkCode);
                logger.info("sBnkCode"+ " "+sBnkCode);
                invStagingRec.addPaymentMeansCode(stagingPayMCode);
                logger.info("stagingPayMCode"+ " "+stagingPayMCode);
                logger.info("after adding payMcode invStagingRec :"+" "+ invStagingRec);
                // CRea
                // Modified Code to update fee amount as charge amount
                if (invoiceFee.equals("Y")) {
                    logger.info("inside invoiceFee"+ " "+invoiceFee);

                    stagingChrgInd = new ChargeIndicatorClass();
                    stagingChrgInd.setChargeIndicator(sInvChrgIndicator);
                    logger.info("sInvChrgIndicator"+ " "+sInvChrgIndicator);
                    stagingChrgInd.setChargeReasonCode(sInvChrgRsnCode);
                    logger.info("sInvChrgRsnCode"+ " "+sInvChrgRsnCode);
                    stagingChrgInd.setChargeReason(sInvFeeDesc);
                    logger.info("sInvFeeDesc"+ " "+sInvFeeDesc);
                    stagingChrgInd.setChargeAmount(invoiceFeeAmt.toString());
                    logger.info("invoiceFeeAmt"+ " "+invoiceFeeAmt);
                    stagingChrgInd.setChargeCcy(sInvCcy);
                    logger.info("sInvCcy"+ " "+sInvCcy);
                    stagingChrgInd.setChargeTaxCategory(sInvChrgTaxCode);
                    logger.info("sInvChrgTaxCode"+ " "+sInvChrgTaxCode);
                    stagingChrgInd.setChargeTaxSchemeId(sInvChrgTaxSchemeId);
                    logger.info("sInvChrgTaxSchemeId"+ " "+sInvChrgTaxSchemeId);
                    invStagingRec.addChargeIndicator(stagingChrgInd);
                    logger.info("stagingChrgInd"+ " "+stagingChrgInd);

                }

                stagingTaxAmt.setTaxAmount(sTaxAmt);
                logger.info("sTaxAmt"+ " "+sTaxAmt);
                stagingTaxAmt.setTaxCcy(sInvCcy);
                logger.info("sInvCcy"+ " "+sInvCcy);
                stagingTaxAmt.setTaxTaxableAmt(String.valueOf(detsTotAmt));
                logger.info("detsTotAmt"+ " "+detsTotAmt);
                stagingTaxAmt.setTaxTaxableCcy(sInvCcy);
                logger.info("sInvCcy"+ " "+sInvCcy);

                stagingSubTot.setTaxSubtotAmt(sTaxAmt);
                logger.info("sTaxAmt"+ " "+sTaxAmt);
                stagingSubTot.setTaxSubtotCcy(sInvCcy);
                logger.info("sInvCcy"+ " "+sInvCcy);
                stagingSubTot.setTaxCategory(sInvTaxCateg);
                logger.info("sInvTaxCateg"+ " "+sInvTaxCateg);
                stagingSubTot.setTaxExemptionCode(sTaxExmpCode);
                logger.info("sTaxExmpCode"+ " "+sTaxExmpCode);
                stagingSubTot.setTaxSchemeId(sTaxSchemeId);
                logger.info("sTaxSchemeId"+ " "+sTaxSchemeId);
                stagingTaxAmt.addTaxSubtotAmt(stagingSubTot);
                logger.info("stagingSubTot"+ " "+stagingSubTot);
                invStagingRec.addTaxAmount(stagingTaxAmt);
                logger.info("stagingTaxAmt"+ " "+stagingTaxAmt);

                invStagingRec.setTLineExtensionAmount(String.valueOf(payableAmt));
                logger.info("setTLineExtensionAmount"+ " "+payableAmt);
                invStagingRec.setTLineExtensionCcy(sInvCcy);
                logger.info("sInvCcy"+ " "+sInvCcy);
                invStagingRec.setTTaxExclusiveAmount(String.valueOf(detsTotAmt));
                logger.info("setTTaxExclusiveAmount"+ " "+detsTotAmt);
                invStagingRec.setTTaxExclusiveCcy(sInvCcy);
                logger.info("setTTaxExclusiveCcy"+ " "+sInvCcy);
                invStagingRec.setTTaxInclusiveAmount(String.valueOf(detsTotAmt));
                logger.info("setTTaxInclusiveAmount"+ " "+detsTotAmt);
                invStagingRec.setTTaxInclusiveCcy(sInvCcy);
                logger.info("sInvCcy"+ " "+sInvCcy);
                invStagingRec.setTPrepaidAmount(String.valueOf(sPrepaidAmt));
                logger.info("setTPrepaidAmount"+ " "+sPrepaidAmt);
                invStagingRec.setTPrepaidCcy(sInvCcy);
                logger.info("setTPrepaidCcy"+ " "+sInvCcy);
                invStagingRec.setTPayableAmount(String.valueOf(detsTotAmt));
                logger.info("setTPayableAmount"+ " "+detsTotAmt);
                invStagingRec.setTPayableCcy(sInvCcy);
                logger.info("setTPayableCcy"+ " "+sInvCcy);
                invStagingRec.setTChargeTotAmount(invoiceFeeAmt.toString());
                logger.info("setTChargeTotAmount"+ " "+invoiceFeeAmt);
                invStagingRec.setTChargeTotCcy(sInvCcy);
                logger.info("setTChargeTotCcy"+ " "+sInvCcy);
                invStagingRec.setCustomerType(detsCustomerType);
                logger.info("setCustomerType"+ " "+detsCustomerType);
                invStagingRec.setNote(invNote, 0);
                logger.info("setNote"+ " "+invNote);
                updCustomAndProfileId(invStagingRec,sTCustomisation, sTProfileId, invParamRec );
                logger.info("staging Record"+ " "+invStagingRec);
                //detsCustomerType



                // Mapping invoice details data to staging table

                for(int linePos=0;linePos<lstdetsVArrIdsCnt;linePos++) {
                    String arrangementId = lstdetsArrIds.get(linePos).getArrangementId().toString();
                    AaArrangementRecord aaRec = new AaArrangementRecord(da.getRecord("AA.ARRANGEMENT", arrangementId));
                    String aaProdId = aaRec.getProduct(0).getProduct().getValue();
                    AaProductRecord aaProdRec = new AaProductRecord(da.getRecord("AA.PRODUCT", aaProdId));
                    aaProductDesc = aaProdRec.getDescription(0).getValue();
                    List<LineIdClass> lineIdList= lstdetsArrIds.get(linePos).getLineId();
                    int lineIdCnt = lineIdList.size();
                    for(int line=0;line<lineIdCnt;line++){
                        String lineId = lineIdList.get(line).getLineId().toString();
                        String lineAmnt = lineIdList.get(line).getAmount().toString();
                        String lineAmntType = lineIdList.get(line).getAmountType().toString();
                        String prodDesc =  aaProductDesc+"-"+lineAmntType;
                        stagingLID = new LIdClass();
                        //  stagingLID.setLInvoicedQuantity(sLInvQuantity);
                        stagingLID.setLId(lineId);
                        logger.info("lineId"+ " "+lineId);
                        stagingLID.setLInvoicedQuantity(sLInvQuantity);
                        logger.info("sLInvQuantity"+ " "+sLInvQuantity);
                        stagingLID.setLUnitCode(pUnitCode);
                        logger.info("pUnitCode"+ " "+pUnitCode);
                        stagingLID.setLLineExtensionAmount(lineAmnt);
                        logger.info("amt"+ " "+lineAmnt);
                        stagingLID.setLLineExtensionCcy(sInvCcy);
                        logger.info("sInvCcy"+ " "+sInvCcy);
                        stagingLID.setLDocId(arrangementId );
                        logger.info("arrId"+ " "+arrangementId );
                        stagingLID.setLDocSchemeId(sLDocSchemeId);
                        logger.info("sLDocSchemeId"+ " "+sLDocSchemeId);
                        stagingLID.setLDocTypeCode(sLDocCodeType);
                        logger.info("sLDocCodeType"+ " "+sLDocCodeType);
                        stagingLID.setLName(prodDesc);
                        logger.info("prodDesc"+ " "+prodDesc);
                        stagingLID.setLTaxCategoryId(pTaxCateg);
                        logger.info("pTaxCateg"+ " "+pTaxCateg);
                        stagingLID.setLTaxSchemeId(sTaxSchemeId);
                        logger.info("sTaxSchemeId"+ " "+sTaxSchemeId);
                        stagingLID.setLPriceAmount(lineAmnt);
                        logger.info("amt"+ " "+lineAmnt);
                        stagingLID.setLPriceCcy(sInvCcy);
                        logger.info("sInvCcy"+ " "+sInvCcy);
                        stagingLID.setLNote(lineAmntType, 0);
                        logger.info("lineAmntType"+ " "+lineAmntType);
                        invStagingRec.addLId(stagingLID);
                        logger.info("stagingLID :"+" "+ stagingLID);
                    }

                }
            }
            if(!(invStagingRec==null)){
                invDetsRec.setStatus("SENDING");
                updInvDetails(id, transactionData, records, invDetsRec, coCode);
            }
            updStagingRec(id, transactionData, records,invStagingRec,coCode,detsKidNo);


            //***************************TYPE-C*************************************
            if (idType.equals("C")) {
                // Create new record in Staging

                invStagingRec.setInvoiceDetailsId(id, 0);
                invStagingRec.setType(invDetsType);
                invStagingRec.setCaseId(detsCaseId);
                logger.info("823 invStagingRec :"+" "+ invStagingRec);
                for(int lstCustCnt = 0; lstCustCnt< lstInvDetsCustClassCnt ;lstCustCnt++){
                    String sCusData = "";
                    String sCusClsId = "";
                    String sRegClsId = "";
                    String sRstStatus = "";
                    logger.info("Inside C loop");
                    try{
                        sCusData = lstCustdets.get(lstCustCnt);
                    }catch(Exception e){}
                    try{
                        sCusClsId = sCusData.split("\\*")[0];
                    }catch(Exception e){}
                    try{
                        sRegClsId = sCusData.split("\\*")[1];
                    }catch(Exception e){}
                    try{
                        sRstStatus = sCusData.split("\\*")[2];
                    }catch(Exception e){}
                    stagingCust = new com.temenos.t24.api.tables.ebhbinvoicestaging.CustomerIdClass();
                    stagingCust.setCustomerId(sCusClsId);
                    stagingCust.setRegisterId(sRegClsId);
                    stagingCust.setDbtRestStatus(sRstStatus);
                    invStagingRec.addCustomerId(stagingCust);
                }

                invStagingRec.setCustomizationId(sCustomisation,0);
                logger.info("sCustomisation"+sCustomisation);
                invStagingRec.setProfileId(sProfileId,0);
                logger.info("sProfileId"+sProfileId);
                invStagingRec.setFileId(detsInvNo);
                logger.info("detsInvNo"+detsInvNo);
                invStagingRec.setIssueDate(sInvIssueDate);

                invStagingRec.setCreditNoteTypeCode(sInvCrNote);
                logger.info("sInvCrNote"+sInvCrNote);
                invStagingRec.setDocumentCurrencyCode(sInvCcy);
                logger.info("sInvCcy"+sInvCcy);
                invStagingRec.setBuyerReference(sInvCustRef);
                logger.info("sInvCustRef"+sInvCustRef);
                invStagingRec.setInvoiceDocumentRef(detsCaseId);
                logger.info("detsCaseId"+detsCaseId);
                invStagingRec.setContractDocumentRef(detsCaseId);
                logger.info("detsCaseId"+detsCaseId);
                invStagingRec.setSEndPointId(sCompId);
                invStagingRec.setSSchemeId(sSchemeId);
                invStagingRec.setSName(sAddName);
                invStagingRec.setSStreetName(sAddStreet);
                invStagingRec.setSCityName(sAddTown);
                invStagingRec.setSPostalZone(addPostCode);
                invStagingRec.setSCountryCode(sAddCountry);
                invStagingRec.setSRegistrationName(sAddName);
                invStagingRec.setSCompanyId(sCompId);
                invStagingRec.setSCompanySchemeId(sSchemeId);
                logger.info("sSchemeId"+sSchemeId);

                invStagingRec.setBEndPointId(sRegId);
                logger.info("sRegId"+sRegId);
                invStagingRec.setBSchemeId(sSchemeId);
                logger.info("sSchemeId"+sSchemeId);
                invStagingRec.setBName(sDeAddrName);
                logger.info("sDeAddrName"+sDeAddrName);
                invStagingRec.setBAddStreetName(cusAddress1);
                invStagingRec.setBStreetName(sDeAddrStrtAddr);
                invStagingRec.setBCityName(sDeAddrTownCountry);
                invStagingRec.setBPostalZone(sDeAddrPostCode);
                invStagingRec.setBCountrySubentity(sDeAddrCountry);
                invStagingRec.setBCountryCode(cusAddressCntry);
                invStagingRec.setBRegistrationName(sDeAddrName);

                logger.info("sDeAddrName"+sDeAddrName);
                stagingPayMCode.setPaymentMeansCode(sInvPaymntChannel);
                stagingPayMCode.setPaymentId(detsKidNo);
                stagingPayMCode.setPaymentAccount(sBnkCode);
                invStagingRec.addPaymentMeansCode(stagingPayMCode);
                logger.info("stagingPayMCode"+stagingPayMCode);

                if (invoiceFee.equals("Y")) {  
                    logger.info("Inside C loop invoiceFee ");
                    stagingChrgInd = new ChargeIndicatorClass();
                    stagingChrgInd.setChargeIndicator(sInvChrgIndicator);
                    stagingChrgInd.setChargeReasonCode(sInvChrgRsnCode);
                    stagingChrgInd.setChargeReason(sInvFeeDesc);
                    stagingChrgInd.setChargeAmount(invoiceFeeAmt.toString());
                    logger.info("invoiceFeeAmt"+invoiceFeeAmt);
                    stagingChrgInd.setChargeCcy(sInvCcy);
                    stagingChrgInd.setChargeTaxCategory(sInvChrgTaxCode);
                    stagingChrgInd.setChargeTaxSchemeId(sInvChrgTaxSchemeId);
                    invStagingRec.addChargeIndicator(stagingChrgInd);
                    logger.info("stagingChrgInd"+stagingChrgInd);
                }

                stagingTaxAmt.setTaxAmount(sTaxAmt);
                stagingTaxAmt.setTaxCcy(sInvCcy);
                stagingTaxAmt.setTaxTaxableAmt(String.valueOf(detsTotAmt));
                stagingTaxAmt.setTaxTaxableCcy(sInvCcy);
                logger.info("sInvCcy"+sInvCcy);

                stagingSubTot.setTaxSubtotAmt(sTaxAmt);
                stagingSubTot.setTaxSubtotCcy(sInvCcy);
                stagingSubTot.setTaxCategory(sInvTaxCateg);
                stagingSubTot.setTaxExemptionCode(sTaxExmpCode);
                logger.info("sTaxExmpCode"+sTaxExmpCode);

                stagingSubTot.setTaxSchemeId(sTaxSchemeId);
                stagingTaxAmt.addTaxSubtotAmt(stagingSubTot);
                invStagingRec.addTaxAmount(stagingTaxAmt);
                logger.info("901 invStagingRec :"+" "+ invStagingRec);
                invStagingRec.setTLineExtensionAmount(String.valueOf(payableAmt));
                invStagingRec.setTLineExtensionCcy(sInvCcy);
                invStagingRec.setTTaxExclusiveAmount(String.valueOf(detsTotAmt));
                invStagingRec.setTTaxExclusiveCcy(sInvCcy);
                invStagingRec.setTTaxInclusiveAmount(String.valueOf(detsTotAmt));
                invStagingRec.setTTaxInclusiveCcy(sInvCcy);
                invStagingRec.setTPrepaidAmount(String.valueOf(sPrepaidAmt));
                invStagingRec.setTPrepaidCcy("");
                invStagingRec.setTPayableAmount(String.valueOf(detsTotAmt)); // updating inclusive of invoicefee
                invStagingRec.setTPayableCcy(sInvCcy);
                invStagingRec.setTChargeTotAmount(String.valueOf(reminderFeeAmt));
                invStagingRec.setTChargeTotCcy(sInvCcy);
                invStagingRec.setCustomerType(detsCustomerType);
                logger.info("setCustomerType"+ " "+detsCustomerType);
                updCustomAndProfileId(invStagingRec,sTCustomisation, sTProfileId, invParamRec );
                logger.info("914 invStagingRec :"+" "+ invStagingRec);
                // Loop each bill ID

                for(int linePos=0;linePos<lstdetsVArrIdsCnt;linePos++) {
                    String arrangementId = lstdetsArrIds.get(linePos).getArrangementId().toString();
                    AaArrangementRecord aaRec = new AaArrangementRecord(da.getRecord("AA.ARRANGEMENT", arrangementId));
                    String aaProdId = aaRec.getProduct(0).getProduct().getValue();
                    AaProductRecord aaProdRec = new AaProductRecord(da.getRecord("AA.PRODUCT", aaProdId));
                    aaProductDesc = aaProdRec.getDescription(0).getValue();
                    List<LineIdClass> lineIdList= lstdetsArrIds.get(linePos).getLineId();

                    int lineIdCnt = lineIdList.size();
                    for(int line=0;line<lineIdCnt;line++){
                        String lineId = lineIdList.get(line).getLineId().toString();
                        String lineAmnt = lineIdList.get(line).getAmount().toString();
                        String lineAmntType = lineIdList.get(line).getAmountType().toString();
                        String prodDesc =  aaProductDesc+"-"+lineAmntType;
                        //  stagingLID.setLInvoicedQuantity(sLInvQuantity);
                        stagingLID = new LIdClass();
                        stagingLID.setLId(lineId);
                        logger.info("lineId"+ " "+lineId);
                        stagingLID.setLInvoicedQuantity(sLInvQuantity);
                        logger.info("sLInvQuantity"+ " "+sLInvQuantity);
                        stagingLID.setLUnitCode(pUnitCode);
                        logger.info("pUnitCode"+ " "+pUnitCode);
                        stagingLID.setLLineExtensionAmount(lineAmnt);
                        logger.info("amt"+ " "+lineAmnt);
                        stagingLID.setLLineExtensionCcy(sInvCcy);
                        logger.info("sInvCcy"+ " "+sInvCcy);
                        stagingLID.setLDocId(arrangementId );
                        logger.info("arrId"+ " "+arrangementId );
                        stagingLID.setLDocSchemeId(sLDocSchemeId);
                        logger.info("sLDocSchemeId"+ " "+sLDocSchemeId);
                        stagingLID.setLDocTypeCode(sLDocCodeType);
                        logger.info("sLDocCodeType"+ " "+sLDocCodeType);
                        stagingLID.setLName(prodDesc);
                        logger.info("prodDesc"+ " "+prodDesc);
                        stagingLID.setLTaxCategoryId(pTaxCateg);
                        logger.info("pTaxCateg"+ " "+pTaxCateg);
                        stagingLID.setLTaxSchemeId(sTaxSchemeId);
                        logger.info("sTaxSchemeId"+ " "+sTaxSchemeId);
                        stagingLID.setLPriceAmount(lineAmnt);
                        logger.info("amt"+ " "+lineAmnt);
                        stagingLID.setLPriceCcy(sInvCcy);
                        logger.info("sInvCcy"+ " "+sInvCcy);
                        stagingLID.setLNote(lineAmntType, 0);
                        logger.info("lineAmntType"+ " "+lineAmntType);
                        invStagingRec.addLId(stagingLID);
                        logger.info("stagingLID :"+" "+ stagingLID);
                    }

                }
                if(!(invStagingRec==null)){
                    invDetsRec.setStatus("SENDING");
                    updInvDetails(id, transactionData, records, invDetsRec, coCode);
                }
                updStagingRec(id, transactionData, records,invStagingRec,coCode,detsKidNo);
            }
        }

        try {
            logger.info("deleting unprocess id :");
            invUnprocess.delete(id);
            logger.info("deleting unprocess id :"+" "+ id);
        } catch (T24IOException e) {
            Logger.getLogger(e.getMessage());  
        }
    }


    /**
     * @param id
     * @param transactionData
     * @param records
     * @param invDetsRec
     * @param coCode
     */
    private void updInvDetails(String id, List<TransactionData> transactionData, List<TStructure> records,
            EbHbInvoiceDetailsRecord invDetsRec, String coCode) {

        TransactionData txndata = new TransactionData();
        txndata.setVersionId("EB.HB.INVOICE.DETAILS,HUS.OFS");
        txndata.setFunction(function);
        txndata.setSourceId(ofsSrc);
        txndata.setNumberOfAuthoriser("0");
        txndata.setCompanyId(coCode);
        txndata.setTransactionId(id);
        transactionData.add(txndata);
        records.add(invDetsRec.toStructure());
        logger.info("Posting Invoice details :");
    }

    private void updInvoiceLeftOver(List<TransactionData> transactionData, List<TStructure> records, String detsCaseId,
            String coCode, EbHbInvoiceLeftoverRecord invLeftOvrRec) {
        TransactionData lTxndata = new TransactionData();
        lTxndata.setVersionId("EB.HB.INVOICE.LEFTOVER,HUS.OFS");
        lTxndata.setFunction(function);
        lTxndata.setSourceId(ofsSrc);
        lTxndata.setNumberOfAuthoriser("0");
        lTxndata.setCompanyId(coCode);
        lTxndata.setTransactionId(detsCaseId);
        transactionData.add(lTxndata);
        records.add(invLeftOvrRec.toStructure());
        logger.info("Posting Invoice leftover details :");
    }
    private void updStagingRec(String id, List<TransactionData> transactionData, List<TStructure> records,
            EbHbInvoiceStagingRecord invStagingRec, String coCode, String detsKidNo ) {
        TransactionData stxndata = new TransactionData();
        stxndata.setVersionId("EB.HB.INVOICE.STAGING,HUS.OFS");
        logger.info("EB.HB.INVOICE.STAGING,HUS.OFS");
        stxndata.setFunction(function);
        stxndata.setSourceId(ofsSrc);
        logger.info("function"+function);
        stxndata.setNumberOfAuthoriser("0");
        stxndata.setCompanyId(coCode);
        stxndata.setTransactionId(detsKidNo);
        logger.info("detsKidNo"+detsKidNo);
        transactionData.add(stxndata);
        logger.info("stxndata"+stxndata);
        records.add(invStagingRec.toStructure());

    }

    private void updCustomAndProfileId(EbHbInvoiceStagingRecord invStagingRec,List<TField> sTCustomisation, List<TField> sTProfileId,  EbHbInvoiceParamRecord invParamRec ){
        String sCustomisation="";
        try{
            sTCustomisation = invParamRec.getCustomizationId();
            int customCnt =  sTCustomisation.size();
            logger.info("customCnt"+" "+customCnt);
            for(int custom=0;custom<customCnt;custom++) {
                sCustomisation = invParamRec.getCustomizationId().get(custom).toString();
                invStagingRec.setCustomizationId(sCustomisation,custom);
                logger.info("after customization id"+" "+sCustomisation);
            } 
        }catch(Exception e){
        }

        try{
            String sProfileId="";
            sTProfileId = invParamRec.getProfileId();
            int profileCnt = sTProfileId.size();
            logger.info("profileCnt"+" "+profileCnt);
            for(int profileId=0;profileId<profileCnt;profileId++){
                sProfileId = invParamRec.getProfileId().get(profileId).toString();
                invStagingRec.setProfileId(sProfileId,profileId);
                logger.info("after profile id"+ " "+sProfileId);
            }
        }catch(Exception e){
        }
    }
    private DeAddressRecord deAddressProjectParty(String sCusId,DeAddressRecord deAddressRec,DataAccess da) {
        if(sCusId!=null){
            deAddressIds = da.selectRecords("", "DE.ADDRESS", "", "WITH @ID LIKE ..." + sCusId + "...");
            logger.info(" deAddressIds :"+" "+  deAddressIds);
            int deAddressCnt = deAddressIds.size();
            for (int deAddress = 0; deAddress < deAddressCnt; deAddress++) {
                String lstdeId = deAddressIds.get(deAddress);
                if(lstdeId.endsWith("PRINT.1")) {
                    deAddressId = lstdeId;

                }
                deAddressRec = new DeAddressRecord(da.getRecord("DE.ADDRESS", lstdeId));
                deAddrPurpose = deAddressRec.getAddressPurpose().getValue();
                if (!deAddrPurpose.equals("")) {
                    lstdeAddressPurpose.add(deAddrPurpose);
                    lstdeAddressPurposeId.add(lstdeId);
                    logger.info(" deAddrPurpose :"+" "+ deAddrPurpose);
                    logger.info("lstdeId :"+" "+ lstdeId);
                }
            }

            ArrayList<String> list = new ArrayList<>(lstdeAddressPurpose);
            int billIndex = list.indexOf("BILLING");
            int mailIndex = list.indexOf("MAIL");

            if (billIndex != -1) {
                deAddressAPId = lstdeAddressPurposeId.get(billIndex);
            } else if (mailIndex != -1) {
                deAddressAPId = lstdeAddressPurposeId.get(mailIndex);
            } else {
                deAddressAPId = deAddressId;
            }

            logger.info("deAddressAPId :"+" "+deAddressAPId);
            deAddressRec = new DeAddressRecord(da.getRecord("DE.ADDRESS", deAddressAPId));
            logger.info("deAddressRec :"+" "+deAddressRec);
            return deAddressRec;
        }else {
            return deAddressRec;
        }

    }

    private CustomerRecord  customerDetails(CustomerRecord cusRec, DataAccess da,String sCusId,  List<String> custAddList) {

        try {
            cusRec = new CustomerRecord(da.getRecord("CUSTOMER", sCusId));
            logger.info("cusRec :"+" "+cusRec);
            cusAddress1 = cusRec.getAddress(0).get(0).getValue();
            cusAddressCntry = cusRec.getAddressCountry().getValue();
            if(cusAddressCntry.equals("")) {
                cusAddressCntry ="NO";
            }
            custAddList.add(cusAddress1);
            custAddList.add(cusAddressCntry);
            logger.info("custAddList :"+" "+custAddList);
            return cusRec;
        }catch (Exception e) {
            return cusRec;
        }

    }


    private void genLendingChrgAct(List<TransactionData> transactionData, List<TStructure> records, String invoiceArrId,
            String coCode, BigDecimal invoiceFeeAmt, String id) {
        logger.info("invoice id inside genLendingChrgAct :"+id);
        String arrEffDate = id.split("\\.")[2];
        logger.info("arrEffDate :"+arrEffDate);
        int balCnt =1;
        AaArrangementActivityRecord aaaChrgRec = new AaArrangementActivityRecord();
        aaaChrgRec.setActivity("LENDING-CAPTURE.BILL-INVOICEFEE");
        aaaChrgRec.setArrangement(invoiceArrId);
        //    aaaChrgRec.setEffectiveDate(arrEffDate);

        String billReffieldname = "BILL.REF:" + balCnt;
        String billDatefieldname = "BILL.DATE:" + balCnt;
        String payDatefieldname = "PAYMENT.DATE:" + balCnt;
        String payTypefieldname = "PAYMENT.TYPE:" + balCnt;
        String payAmntfieldname = "PAYMENT.AMOUNT:" + balCnt;
        String propfieldname = "PROPERTY:" + balCnt + ":" + balCnt;
        String newPropAmntfieldname = "NEW.PROP.AMT:" + balCnt + ":" + balCnt;
        String billTypefieldname = "BILL.TYPE:" + balCnt;

        PropertyClass propertyRec = new PropertyClass();
        FieldNameClass fieldNameRec = new FieldNameClass();
        propertyRec.setProperty("BALANCE.MAINTENANCE");

        fieldNameRec = new FieldNameClass();
        fieldNameRec.setFieldName(billReffieldname);
        fieldNameRec.setFieldValue("NEW");
        propertyRec.addFieldName(fieldNameRec);
        propertyRec.setFieldName(fieldNameRec, 0);

        fieldNameRec = new FieldNameClass();
        fieldNameRec.setFieldName(billDatefieldname);
        fieldNameRec.setFieldValue(arrEffDate);
        propertyRec.addFieldName(fieldNameRec);
        propertyRec.setFieldName(fieldNameRec, 1);

        fieldNameRec = new FieldNameClass();
        fieldNameRec.setFieldName(payDatefieldname);
        fieldNameRec.setFieldValue(arrEffDate);
        propertyRec.addFieldName(fieldNameRec);
        propertyRec.setFieldName(fieldNameRec, 2);

        fieldNameRec = new FieldNameClass();
        fieldNameRec.setFieldName(payTypefieldname);
        fieldNameRec.setFieldValue("CHARGE");
        propertyRec.addFieldName(fieldNameRec);
        propertyRec.setFieldName(fieldNameRec, 3);


        fieldNameRec = new FieldNameClass();
        fieldNameRec.setFieldName(payAmntfieldname);
        fieldNameRec.setFieldValue(invoiceFeeAmt.toString());
        propertyRec.addFieldName(fieldNameRec);
        propertyRec.setFieldName(fieldNameRec, 4);


        fieldNameRec = new FieldNameClass();
        fieldNameRec.setFieldName(propfieldname);
        fieldNameRec.setFieldValue("INVOICEFEE");
        propertyRec.addFieldName(fieldNameRec);
        propertyRec.setFieldName(fieldNameRec, 5);

        fieldNameRec = new FieldNameClass(); 
        fieldNameRec.setFieldName(newPropAmntfieldname);
        fieldNameRec.setFieldValue(invoiceFeeAmt.toString());
        propertyRec.addFieldName(fieldNameRec);
        propertyRec.setFieldName(fieldNameRec, 6);

        fieldNameRec = new FieldNameClass(); 
        fieldNameRec.setFieldName(billTypefieldname);
        fieldNameRec.setFieldValue("INSTALLMENT");
        propertyRec.addFieldName(fieldNameRec);
        propertyRec.setFieldName(fieldNameRec, 7);

        logger.info("propertyRec :"+propertyRec);

        aaaChrgRec.addProperty(propertyRec);
        // Trigger AA ACTIVITY>LENDING-CHARGE-INVOICEFEE
        TransactionData txndata = new TransactionData();
        txndata.setVersionId("AA.ARRANGEMENT.ACTIVITY,HUS.OFS");
        txndata.setFunction(function);
        txndata.setSourceId(ofsSrc);
        txndata.setNumberOfAuthoriser("0");
        txndata.setCompanyId(coCode);
        transactionData.add(txndata);
        records.add(aaaChrgRec.toStructure());
        logger.info("aaaChrgRec :"+aaaChrgRec);
        logger.info("Posting AAA :");
    }

}
