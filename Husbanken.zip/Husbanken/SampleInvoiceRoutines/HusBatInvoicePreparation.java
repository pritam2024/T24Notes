package com.husbanken.loanmain.invoices;

import java.io.IOException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.logging.FileHandler;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

import com.temenos.api.TDate;
import com.temenos.api.TField;
import com.temenos.api.TStructure;
import com.temenos.api.exceptions.T24CoreException;
import com.temenos.t24.api.arrangement.accounting.Contract;
import com.temenos.t24.api.complex.eb.servicehook.ServiceData;
import com.temenos.t24.api.complex.eb.servicehook.TransactionData;
import com.temenos.t24.api.hook.system.ServiceLifecycle;
import com.temenos.t24.api.records.aabilldetails.AaBillDetailsRecord;
import com.temenos.t24.api.records.aabilldetails.PaymentTypeClass;
import com.temenos.t24.api.records.aabilldetails.PropertyClass;
import com.temenos.t24.api.records.customer.CustomerRecord;
import com.temenos.t24.api.records.dates.DatesRecord;
import com.temenos.t24.api.system.DataAccess;
import com.temenos.t24.api.system.Date;
import com.temenos.t24.api.tables.ebhbcasetodaybills.EbHbCaseTodayBillsRecord;
import com.temenos.t24.api.tables.ebhbcasetodaybills.EbHbCaseTodayBillsTable;
import com.temenos.t24.api.tables.ebhbinvoicedetails.ArrangementIdClass;
import com.temenos.t24.api.tables.ebhbinvoicedetails.CustomerIdClass;
import com.temenos.t24.api.tables.ebhbinvoicedetails.EbHbInvoiceDetailsRecord;
import com.temenos.t24.api.tables.ebhbinvoicedetails.LineIdClass;
import com.temenos.t24.api.tables.ebhbinvoiceleftover.EbHbInvoiceLeftoverRecord;
import com.temenos.t24.api.tables.ebhbinvoiceleftover.InvoiceIdClass;
import com.temenos.t24.api.tables.ebhbinvoiceparam.EbHbInvoiceParamRecord;
import com.temenos.t24.api.tables.ebhbinvoiceparam.InvMinAmountCcyClass;
import com.temenos.t24.api.tables.ebhuslacase.EbHusLaCaseRecord;
import com.temenos.t24.api.tables.ebhuslacase.ProjectPartyClass;

/**
 * Developed on :
 * 
 * @author 10673048
 * 
 *         Developed For : LoanMaintenance_LM04 - Invoices and credit notes_V2
 * 
 *         Attached to : BATCH>BNK/HusBatInvoicePreparation
 * 
 *         Attached As : COB job at Online stage
 * 
 *         Description : Routine to update EB.HB.INVOICE.DETAILS with bills details which are created in COB .
 */
public class HusBatInvoicePreparation extends ServiceLifecycle {
    private static final String ofsSrc = "HUS.LOAN.GT";
    private static final String function = "INPUT";
    private static String INVOICEDETSVERSION = "EB.HB.INVOICE.DETAILS,HUS.INPUT";
    private static DecimalFormat df = new DecimalFormat("0.00");
    List<PropertyClass> propertyList = null;
    List<TField> accPropertyLst = null;
    List<TField> prinIntPropertyLst = null;
    List<TField> penalIntPropertyLst = null;
    List<TField> chrgIntPropertyLst = null;
    List<TField> costPropertyLst = null;
    EbHbInvoiceParamRecord invParamRec = null;
    String accPropertyLst1 = "";
    String prinIntPropertyLst1 = "";
    String penalIntPropertyLst1 = "";
    String chrgIntPropertyLst1 = "";
    String costPropertyLst1 = "";
    String arrId = "";
    String hbCaseId = "";
    String todayDate = "";
    EbHbInvoiceDetailsRecord hbInvDetsRecofs = null;
    boolean payFinalDemandFlag = false;

    List<TField> b2BStatusList = null;
    List<TField> b2CStatusList = null;
    String b2BStatusList1 = "";
    String b2CStatusList1 = "";
    EbHbInvoiceDetailsRecord hbInvDetsRecNew = new EbHbInvoiceDetailsRecord();

    @Override
    public List<String> getIds(ServiceData serviceData, List<String> controlList) {
        // TODO Auto-generated method stub

        Logger logger = Logger.getLogger("HusBatInvoicePreparation-Select process");
        try {

            FileHandler fileHandler = new FileHandler("../../../../../srv/Temenos/TAFJ/log/InvoicePrepLogicLog.txt");
            logger.addHandler(fileHandler);
            SimpleFormatter formatter = new SimpleFormatter();
            fileHandler.setFormatter(formatter);
        } catch (SecurityException e ) {

        } catch (IOException e) {
        }
        List<String> recids = null;
        DataAccess da = new DataAccess(this);
        recids = da.selectRecords("BNK", "EB.HB.CASE.TODAY.BILLS", "", "");
        logger.info("List of all records under EB.HB.CASE.TODAY.BILLS table :"+" "+recids);
        return recids;
    }

    @Override
    public void postUpdateRequest(String id, ServiceData serviceData, String controlItem,
            List<TransactionData> transactionData, List<TStructure> records) {
        // TODO Auto-generated method stub
        Logger logger = Logger.getLogger("HusBatInvoicePreparation-Main process");
        try {

            FileHandler fileHandler = new FileHandler("../../../../../srv/Temenos/TAFJ/log/InvoicePrepLogicLog.txt");
            logger.addHandler(fileHandler);
            SimpleFormatter formatter = new SimpleFormatter();
            fileHandler.setFormatter(formatter);
        } catch (SecurityException e ) {
            // Security Exception e
        } catch (IOException e) {
            // IO Exception e
        }

        logger.info("friday log 1");
        DataAccess da = new DataAccess(this);
        EbHbCaseTodayBillsTable ebHbCaseTodayBillsTable = new EbHbCaseTodayBillsTable(this);
        EbHbCaseTodayBillsRecord ebHbCaseTodayBillsRec = null;
        TransactionData trans1 = null;
        try {
            ebHbCaseTodayBillsRec = new EbHbCaseTodayBillsRecord(da.getRecord("EB.HB.CASE.TODAY.BILLS", id));
            logger.info("EB.HB.CASE.TODAY.BILLS Record is available:"+" "+ebHbCaseTodayBillsRec);
            EbHusLaCaseRecord lacaseRec = new EbHusLaCaseRecord(da.getRecord("EB.HUS.LA.CASE", id));
            logger.info("La case Record :"+" "+lacaseRec);
            List<com.temenos.t24.api.tables.ebhbcasetodaybills.ArrangementIdClass> arrIdList = ebHbCaseTodayBillsRec.getArrangementId();
            logger.info("arrIdList :"+" "+arrIdList);
            List<String> pTypeBillIds = new ArrayList<String>();
            //            bug fix - start
            Map<String, Object> pTypeBillIdsMap = new HashMap<>();
            Set<String> billDateSet = new HashSet<>();
            String billDate = "";
            //            bug fix - end
            List<String> cTypeBillIds = new ArrayList<String>();
            List<String> iTypeBillIds = new ArrayList<String>();
            List<String> caseArrList = new ArrayList<String>();
            String husInvDetsIdType = "";
            String hbInvoiceDetsPtypeId = "";

            String hbInvoiceDetsCtypeId = "";
            String hbInvoiceDetsItypeId = "";
            int totCntArrIds = arrIdList.size();
            int arrIdsCnt = 0;
            String tdyDateVal = "";
            for (arrIdsCnt = 0;arrIdsCnt<totCntArrIds;arrIdsCnt++){
                String arrId = arrIdList.get(arrIdsCnt).getArrangementId().getValue();
                String arrActDate = arrIdList.get(arrIdsCnt).getActDate().getValue();
                logger.info("String arrActDate :"+" "+arrActDate);
                TDate actDate = new TDate(arrActDate);
                // for (com.temenos.t24.api.tables.ebhbcasetodaybills.ArrangementIdClass arrIdTemp : arrIdList) {
                //   logger.info("arrIdTemp :"+" "+arrIdTemp);
                Date date = new Date(this);
                DatesRecord dateRec = date.getDates();
                todayDate = dateRec.getToday().getValue();
                TDate tdyDate = new TDate(todayDate);
                tdyDateVal = tdyDate.toString();
                logger.info("todayDate :"+" "+todayDate);
                //  arrId = arrIdTemp.toString();
                logger.info("arrId :"+" "+arrId);
                boolean aaInvParmFlag = false;
                try {
                    invParamRec = new EbHbInvoiceParamRecord(da.getRecord("EB.HB.INVOICE.PARAM", "SYSTEM"));
                    aaInvParmFlag = true;
                    logger.info("aaInvParmFlag is set to true as SYSTEM record is available under EB.HB.INVOICE.PARAM  table ");
                } catch (Exception e) {
                    throw new T24CoreException("SYSTEM record missing in PARAM file");
                }
                String hbInvoiceDetsIdFin = "";
                String billITemp = "";
                String billPTemp = "";
                String billCTemp = "";
                //    if (arrActDate.compareTo(todayDate)==0){
                if (aaInvParmFlag) { // To proceed only when SYSTEM record is available in Param table.
                    logger.info("gets proceeded as SYSTEM record is available under EB.HB.INVOICE.PARAM  table ");
                    accPropertyLst1 = invParamRec.getAccountProperty().toString();
                    prinIntPropertyLst1 = invParamRec.getPrincipalIntProperty().toString();
                    penalIntPropertyLst1 = invParamRec.getPenaltyIntProperty().toString();
                    chrgIntPropertyLst1 = invParamRec.getChargeProperty().toString();
                    costPropertyLst1 = invParamRec.getCostProperty().toString();
                    accPropertyLst = invParamRec.getAccountProperty();
                    prinIntPropertyLst = invParamRec.getPrincipalIntProperty();
                    penalIntPropertyLst = invParamRec.getPenaltyIntProperty();
                    chrgIntPropertyLst = invParamRec.getChargeProperty();
                    costPropertyLst = invParamRec.getCostProperty();
                    b2BStatusList = invParamRec.getB2bCustomerStatus();
                    b2CStatusList = invParamRec.getB2cCustomerStatus();
                    b2BStatusList1 = invParamRec.getB2bCustomerStatus().toString();
                    b2CStatusList1 = invParamRec.getB2cCustomerStatus().toString();

                    logger.info("b2BStatusList1 :"+" "+b2BStatusList1);
                    logger.info("b2CStatusList1:"+" "+b2CStatusList1);
                    //
                    Contract contractRec = new Contract(this);
                    contractRec.setContractId(arrId);
                    caseArrList.add(arrId);
                    //    List<String> billIds = contractRec.getBillIdsForDate(tdyDate);
                    List<String> billIds = contractRec.getBillIdsForDate(actDate);
                    logger.info("actDate :"+" "+actDate);
                    logger.info("List of bill ids for today date :"+" "+billIds);
                    List<PropertyClass> propertyList = null;                  
                    for (String billId : billIds) {
                        logger.info("Individual billId :"+" "+billId);
                        AaBillDetailsRecord billDetsRec = new AaBillDetailsRecord(da.getRecord("AA.BILL.DETAILS", billId));
                        logger.info("Bill details record :"+" "+billDetsRec);
                        PaymentTypeClass paymentType = billDetsRec.getPaymentType(0); //taking only first multivalue, as - Invoicing issue date: AA.BILL.DETAILS> BILL.DATE (1st multivalue) - defined in FSD
                        PropertyClass propList = billDetsRec.getProperty(0);
                        String invProp = propList.getProperty().getValue();
                        logger.info("invProp is :"+" "+invProp);
                        /*if (invProp.equals("INVOICEFEE")){
                            break;
                        }*/
                        logger.info("paymentType list under bill record :"+" "+paymentType);
                        billDate = paymentType.getBillDate().getValue();
                        logger.info("Bill date under paymentType class :"+" "+billDate);
                        String paymentTypeVal = paymentType.getPaymentType().getValue();
                        logger.info("paymentTypeVal under paymentType class :"+" "+paymentTypeVal);
                        String paymentIndicator = billDetsRec.getPaymentIndicator().getValue();
                        logger.info("paymentIndicator under bill record :"+" "+paymentIndicator);
                        String billCcy = billDetsRec.getCurrency().getValue();
                        logger.info("billCcy under bill record :"+" "+billCcy);

                        // Logic to decide AA.HB.INVOICE.DETAILS id type
                        boolean premiumProp = false;
                        logger.info("premiumProp flag initialisation is :"+" "+premiumProp);
                        propertyList = billDetsRec.getProperty();
                        logger.info("propertyList from bill record variable billDetsRec  :"+" "+propertyList);
                        for (PropertyClass propNames : propertyList) {
                            logger.info("List of all property from propertylist  :"+" "+propNames);
                            String propertyName = propNames.getProperty().getValue();
                            logger.info("propertyName under propNames :"+" "+propertyName);
                            if (propertyName.equalsIgnoreCase("PREMIUM")) { // to
                                // check
                                // for
                                // P
                                // type
                                premiumProp = true;
                                logger.info("premiumProp flag set to true as property name is set to PREMIUM :"+" "+premiumProp);
                            }
                        }
                        husInvDetsIdType = "I"; // invoice type
                        logger.info("setting husInvDetsIdType to :"+" "+husInvDetsIdType);
                        // Customer
                        if (paymentTypeVal.equalsIgnoreCase("FINAL.DEMAND.PAYMENT")) {
                            payFinalDemandFlag = true;
                            logger.info("payFinalDemandFlag flag set to true as paymentTypeVal is set to FINAL.DEMAND.PAYMENT :"+" "+paymentTypeVal);
                        }
                        // Customer
                        if ((paymentIndicator.equalsIgnoreCase("Debit")&& paymentTypeVal.equalsIgnoreCase("PAYOFF$CURRENT"))|| (paymentIndicator.equalsIgnoreCase("Debit")&& paymentTypeVal.equalsIgnoreCase("SPECIAL"))|| (paymentIndicator.equalsIgnoreCase("Debit") && premiumProp)|| (paymentIndicator.equalsIgnoreCase("Debit")&& paymentTypeVal.equalsIgnoreCase("LOSS.SHARING"))) {
                            String husInvDetsPIdType = "P"; // payment request type
                            logger.info("setting husInvDetsPIdType to :"+" "+husInvDetsPIdType);
                            //                          bug fix
                            //                            hbInvoiceDetsPtypeId = husInvDetsPIdType + "." + id + "." + billDate + "." + billCcy;
                            hbInvoiceDetsPtypeId = husInvDetsPIdType + "." + id + "." + todayDate + "." + billCcy;
                            billDateSet.add(billDate);
                            logger.info("Invoice details record id :"+" "+hbInvoiceDetsPtypeId);

                            // pTypeBillIds.add(billId);
                            if (billPTemp.isEmpty()) {
                                billPTemp = billId;
                                logger.info("Setting billPTemp if its empty :"+" "+billPTemp);
                            } else {
                                billPTemp = billPTemp + "*" + billId;
                                logger.info("add billPTemp if its available already :"+" "+billPTemp);
                            }
                            husInvDetsIdType = "";
                        }

                        if (paymentIndicator.equalsIgnoreCase("Credit")) {
                            logger.info("goes inside IF condition if paymentIndicator is set as CREDIT :"+" "+paymentIndicator);
                            if (!paymentTypeVal.equalsIgnoreCase("DISBURSEMENT.%")) {
                                logger.info("goes inside IF condition if paymentTypeVal is set as DISBURSEMENT.% :"+" "+paymentTypeVal);
                                String husInvDetsCIdType = "C"; // Credit Notes type
                                hbInvoiceDetsCtypeId = husInvDetsCIdType + "." + id + "." + billDate + "." + billCcy;
                                logger.info("setting hbInvoiceDetsCtypeId to :"+" "+hbInvoiceDetsCtypeId);
                                if (billCTemp.isEmpty()) {
                                    billCTemp = billId;
                                    logger.info("Setting billCTemp if its empty :"+" "+billCTemp);
                                } else {
                                    billCTemp = billCTemp + "*" + billId;
                                    logger.info("add billCTemp if its available already :"+" "+billCTemp);
                                }

                            }

                            husInvDetsIdType = "";
                        }
                        if (husInvDetsIdType.equalsIgnoreCase("I")) {
                            logger.info("If husInvDetsIdType is I");
                            hbInvoiceDetsItypeId = husInvDetsIdType + "." + id + "." + billDate + "." + billCcy; // Invoice
                            logger.info("invoice details record id hbInvoiceDetsItypeId is :"+" "+hbInvoiceDetsItypeId);                                                                          // detail
                            if (billITemp.isEmpty()) {
                                billITemp = billId;
                                logger.info("Setting billITemp if its empty :"+" "+billITemp);
                            } else {
                                billITemp = billITemp + "*" + billId;
                                logger.info("add billITemp if its available already :"+" "+billITemp);
                            } // id
                        }
                    } // 1st bill loop

                } // PARAM if check
                //   }
                if ((!billITemp.isEmpty())) {
                    logger.info("if billITemp is empty :"+" "+billITemp);
                    String arrWithBill = arrId + "&" + billITemp;
                    logger.info("arrWithBill :"+" "+arrWithBill);
                    iTypeBillIds.add(arrWithBill);
                    logger.info("iTypeBillIds :"+" "+iTypeBillIds);
                }
                if ((!billPTemp.isEmpty())) {
                    logger.info("if billPTemp is empty :"+" "+billPTemp);
                    String arrWithBill = arrId + "&" + billPTemp;
                    logger.info("arrWithBill :"+" "+arrWithBill);
                    pTypeBillIds.add(arrWithBill);
                    //                    bug fix
                    List<String> newpTypeBillIdsList = (List<String>) pTypeBillIdsMap.get(billDate);
                    if (newpTypeBillIdsList == null) {
                        logger.info("newpTypeBillIdsList is null");
                        newpTypeBillIdsList = new ArrayList<>();                        
                    }
                    newpTypeBillIdsList.add(arrWithBill);
                    pTypeBillIdsMap.put(billDate, newpTypeBillIdsList);                    

                    logger.info("pTypeBillIds :"+" "+pTypeBillIds);
                }
                if ((!billCTemp.isEmpty())) {
                    logger.info("if billCTemp is empty :"+" "+billCTemp);
                    String arrWithBill = arrId + "&" + billCTemp;
                    logger.info("arrWithBill :"+" "+arrWithBill);
                    cTypeBillIds.add(arrWithBill);
                    logger.info("cTypeBillIds :"+" "+cTypeBillIds);
                }
                //   }
            } // arrangement loop
            // Checks to post OFS based payment indicator
            // I Type check
            // arrIdsCnt = totCntArrIds-1;
            logger.info("before if check iTypeBillIds :"+" "+iTypeBillIds);
            if ((!iTypeBillIds.isEmpty())) {
                logger.info("if iTypeBillIds is available :"+" "+iTypeBillIds);
                trans1 = new TransactionData();
                boolean sInvFlag = false;
                boolean strFlag = hbOfs(lacaseRec, iTypeBillIds, hbInvoiceDetsItypeId, id, trans1, transactionData, records, sInvFlag);
                logger.info("hbInvoiceDetsItypeId :"+" "+hbInvoiceDetsItypeId);
                logger.info("if iTypeBillIds is available :"+" "+iTypeBillIds);
                if (strFlag){
                    transactionData.add(trans1);
                    records.add(hbInvDetsRecofs.toStructure());
                }
                logger.info("if hbInvDetsRecofs is available :"+" "+hbInvDetsRecofs);

            }
            // P Type check
            if ((!pTypeBillIds.isEmpty())) {
                logger.info("if pTypeBillIds is available :"+" "+pTypeBillIds);

                //                bug fix                
                int index = 1;
                int billDateSetSize = billDateSet.size();
                for (String billDateTemp : billDateSet) {
                    logger.info("billDateTemp :"+" "+billDateTemp);
                    logger.info("pTypeBillIdsMap.get(hbInvoiceDetsPtypeIdTemp) :"+" "+(List<String>) pTypeBillIdsMap.get(billDateTemp));
                    TransactionData trans = new TransactionData();
                    boolean sInvFlag = false;
                    if(billDateSetSize > 1) {
                        hbOfs(lacaseRec, (List<String>) pTypeBillIdsMap.get(billDateTemp), hbInvoiceDetsPtypeId+"."+index, id, trans, transactionData, records,sInvFlag);
                    } else {
                        hbOfs(lacaseRec, (List<String>) pTypeBillIdsMap.get(billDateTemp), hbInvoiceDetsPtypeId, id, trans, transactionData, records, sInvFlag);
                    }                        
                    logger.info("trans :"+" "+trans.toString());
                    transactionData.add(trans);
                    logger.info("transactionData :"+" "+transactionData.toString());
                    records.add(hbInvDetsRecofs.toStructure());
                    logger.info("if hbInvDetsRecofs is available 1:"+" "+hbInvDetsRecofs);
                    index++;
                }

                //                trans1 = new TransactionData();
                //                hbOfs(lacaseRec, pTypeBillIds, hbInvoiceDetsPtypeId, id, trans1);
                //                logger.info("hbInvoiceDetsPtypeId :"+" "+hbInvoiceDetsPtypeId);
                //                logger.info("if pTypeBillIds is available :"+" "+pTypeBillIds);
                //                transactionData.add(trans1);                
            }
            // C Type check
            if ((!cTypeBillIds.isEmpty())) {
                logger.info("if cTypeBillIds is available :"+" "+cTypeBillIds);
                trans1 = new TransactionData();
                boolean sInvFlag = false;
                hbOfs(lacaseRec, cTypeBillIds, hbInvoiceDetsCtypeId, id, trans1, transactionData, records, sInvFlag);
                logger.info("hbInvoiceDetsCtypeId :"+" "+hbInvoiceDetsCtypeId);
                logger.info("if cTypeBillIds is available :"+" "+cTypeBillIds);
                transactionData.add(trans1);
                records.add(hbInvDetsRecofs.toStructure());
                logger.info("if cTypeBillIds is available :"+" "+hbInvDetsRecofs);
            }

            ebHbCaseTodayBillsTable.delete(id); // delete processed case id
            logger.info("ebHbCaseTodayBillsTable is deleted");
        } catch (Exception e) {
            /* try {
                ebHbCaseTodayBillsTable.delete(id);
                logger.info("ebHbCaseTodayBillsTable is deleted as EB.HB.CASE.TODAY.BILLS Record is not available");
            } catch (T24IOException e1) {

            } // delete processed case id
             */        
        }
    }

    public boolean hbOfs(EbHusLaCaseRecord lacaseRecTemp, List<String> arrbills, String hbInvoiceDetsId, String id,
            TransactionData trans, List<TransactionData> transactionData, List<TStructure> records, boolean sInvFlag) {

        Logger logger = Logger.getLogger("HusBatInvoicePreparation-hbOfs process");
        try {

            FileHandler fileHandler = new FileHandler("../../../../../srv/Temenos/TAFJ/log/InvoicePrepLogicLog.txt");
            logger.addHandler(fileHandler);
            SimpleFormatter formatter = new SimpleFormatter();
            fileHandler.setFormatter(formatter);
        } catch (SecurityException e ) {

        } catch (IOException e) {
        }

        logger.info("hbOfs method");

        logger.info("arrbills is available 1:"+" "+arrbills);
        logger.info("hbInvoiceDetsId 1:"+" "+hbInvoiceDetsId);
        logger.info("id 1:"+" "+id);
        logger.info("trans 1:"+" "+trans.toString());
        boolean invFlag = false;
        DataAccess da = new DataAccess(this);
        int existArrSize = 0;
        int billCnt = 0;
        int lineIdCnt = 1;
        String amtType = "";
        String orPropAmt = "";
        double totAmt = 0;
        double amtAdd = 0;
        String hbInvoiceDetsIdNew = "";
        ArrangementIdClass arrSet = new ArrangementIdClass();
        LineIdClass lineIdSet = new LineIdClass();

        boolean accPropFlag = false;
        boolean prinIntPropFlag = false;
        boolean penIntPropFlag = false;
        boolean chgIntPropFlag = false;
        boolean costIntPropFlag = false;

        for (String arrNewId : arrbills) {

            logger.info("arrNewId is available :"+" "+arrNewId);
            logger.info("trans 2: :"+" "+trans.toString());
            logger.info("hbInvoiceDetsId 2:"+" "+hbInvoiceDetsId);

            arrSet = new ArrangementIdClass();
            String billAllIds = arrNewId.split("\\&")[1];
            logger.info("billAllIds :"+" "+billAllIds);
            logger.info("billAllIds :"+" "+billAllIds.length());
            boolean billLast = false;
            int billRemCnt = 0;
            while ((!billAllIds.isEmpty()) && (!billLast)) {
                logger.info("Looping through while loop while ((!billAllIds.isEmpty()) && (!billLast))");
                String billId = billAllIds.split("\\*")[billRemCnt];
                logger.info("billRemCnt :"+" "+billRemCnt);
                logger.info("billId :"+" "+billId);
                boolean enterChgflag = false;
                boolean enterCostflag = false;
                int tempListCnt = 0;
                int tempLineChgCnt = 0;
                int tempLineCostCnt = 0;
                double newChgPropAmt = 0;
                double newCostPropAmt = 0;
                AaBillDetailsRecord billDetsRec = new AaBillDetailsRecord(da.getRecord("AA.BILL.DETAILS", billId));
                logger.info("billDetsRec :"+" "+billDetsRec);
                String paymentDate = billDetsRec.getPaymentDate().getValue();
                String billCcy = billDetsRec.getCurrency().getValue();
                String billArrId = billDetsRec.getArrangementId().getValue();
                PaymentTypeClass paymentType = billDetsRec.getPaymentType(0); 
                String billType = paymentType.getBillType().getValue();
                logger.info("paymentDate :"+" "+paymentDate);
                logger.info("billCcy :"+" "+billCcy);
                logger.info("billArrId :"+" "+billArrId);


                propertyList = billDetsRec.getProperty();
                logger.info("propertyList :"+" "+propertyList);
                for (PropertyClass propNames : propertyList) {
                    logger.info("propNames :"+" "+propNames);
                    String propertyName = propNames.getProperty().getValue();
                    logger.info("propertyName :"+" "+propertyName);
                    orPropAmt = propNames.getOrPropAmount().getValue();
                    logger.info("orPropAmt :"+" "+orPropAmt);

                    // Logic to decide AMOUNT.TYPE field value
                    amtType = "";
                    accPropFlag = false;
                    prinIntPropFlag = false;
                    penIntPropFlag = false;
                    chgIntPropFlag = false;
                    costIntPropFlag = false;
                    if(!(propertyName.equals("INVOICEFEE") && billType.equals("ACT.CHARGE"))){
                        if (!accPropertyLst.isEmpty()) {
                            logger.info("if accPropertyLst is not equal to empty :"+" "+accPropertyLst);
                            accPropFlag = accPropertyLst1.contains(propertyName);
                            logger.info("accPropFlag :"+" "+accPropFlag);
                            if (accPropFlag) {
                                amtType = invParamRec.getAccountDesc().getValue();
                                logger.info("if accPropFlag is available :"+" "+amtType);
                            }
                        }

                        if (!prinIntPropertyLst.isEmpty()) {
                            logger.info("if prinIntPropertyLst is not equal to empty :"+" "+prinIntPropertyLst);
                            prinIntPropFlag = prinIntPropertyLst1.contains(propertyName);
                            logger.info("prinIntPropFlag :"+" "+prinIntPropFlag);
                            if (prinIntPropFlag) {
                                amtType = invParamRec.getPrincipalIntDesc().getValue();
                                logger.info("if prinIntPropFlag is available :"+" "+amtType);
                            }
                        }
                        if (!penalIntPropertyLst.isEmpty()) {
                            logger.info("if penalIntPropertyLst is not equal to empty :"+" "+penalIntPropertyLst);
                            penIntPropFlag = penalIntPropertyLst1.contains(propertyName);
                            logger.info("penIntPropFlag :"+" "+penIntPropFlag);
                            if (penIntPropFlag) {
                                amtType = invParamRec.getPenaltyIntDesc().getValue();
                                logger.info("if penIntPropFlag is available :"+" "+amtType);
                            }
                        }
                        if (!chrgIntPropertyLst.isEmpty()) {
                            logger.info("if chrgIntPropertyLst is not equal to empty :"+" "+chrgIntPropertyLst);
                            chgIntPropFlag = chrgIntPropertyLst1.contains(propertyName);
                            logger.info("chgIntPropFlag :"+" "+chgIntPropFlag);
                            if (chgIntPropFlag) {
                                amtType = invParamRec.getChargeDesc().getValue();
                                logger.info("if chgIntPropFlag is available :"+" "+amtType);
                            }

                        }
                        if (!costPropertyLst.isEmpty()) {
                            logger.info("if costPropertyLst is not equal to empty :"+" "+costPropertyLst);
                            costIntPropFlag = costPropertyLst1.contains(propertyName);
                            logger.info("costIntPropFlag :"+" "+costIntPropFlag);
                            if (costIntPropFlag) {
                                amtType = invParamRec.getCostDesc().getValue();
                                logger.info("if costIntPropFlag is available :"+" "+amtType);
                            }
                        }

                        // New bill and new invoice record logic

                        if (!hbInvoiceDetsIdNew.equalsIgnoreCase(hbInvoiceDetsId)) { // Condition
                            logger.info("Inside if condition");
                            // in
                            // reinitialise
                            // variable
                            // for
                            // diff
                            // id
                            // types
                            // of
                            // invoice
                            // details
                            hbInvoiceDetsIdNew = hbInvoiceDetsId;
                            billCnt = 0;
                            lineIdCnt = 1;
                            logger.info("hbInvoiceDetsIdNew "+hbInvoiceDetsIdNew);
                            logger.info("!hbInvoiceDetsIdNew.equalsIgnoreCase(hbInvoiceDetsId) condition is executed");
                        }

                        if (lineIdCnt == 1) {
                            logger.info("if lineIdCnt is 1");
                            hbInvDetsRecNew = new EbHbInvoiceDetailsRecord(this);
                            arrSet = new ArrangementIdClass();
                            hbInvDetsRecNew.setCaseId(id);
                            hbInvDetsRecNew.setInitialDueDate(paymentDate);
                            hbInvDetsRecNew.setCurrency(billCcy);

                            hbInvDetsRecNew.setIssueDate(todayDate);
                            hbInvDetsRecNew.setStatus("SENDING-GET-CHANNEL");

                            if (!hbInvoiceDetsId.isEmpty()) {
                                hbInvDetsRecNew.setType(hbInvoiceDetsId.split("\\.")[0]);
                            }
                            hbInvDetsRecNew.setDueDate(paymentDate);
                            logger.info("hbInvDetsRecNew :"+" "+hbInvDetsRecNew);
                            // *Customer
                            List<ProjectPartyClass> prjPartyList = lacaseRecTemp.getProjectParty();
                            logger.info("prjPartyList :"+" "+prjPartyList);
                            CustomerIdClass customerset = null;
                            for (ProjectPartyClass prjPartyRec : prjPartyList) {
                                String custNo = prjPartyRec.getProjectParty().getValue();
                                String sendInvoice = prjPartyRec.getSendInvoice().getValue();
                                String partyRole = prjPartyRec.getPartyRole().getValue();
                                customerset = new CustomerIdClass();
                                logger.info("custNo :"+" "+custNo);
                                logger.info("sendInvoice :"+" "+sendInvoice);
                                logger.info("partyRole :"+" "+partyRole);
                                try {
                                    CustomerRecord custRec = new CustomerRecord(da.getRecord("CUSTOMER", custNo));
                                    logger.info("custRec :"+" "+custRec);
                                    if (!sendInvoice.equals("N")){
                                        logger.info("sendInvoice :"+" "+sendInvoice);
                                        String custStatus = custRec.getCustomerStatus().getValue();
                                        String cusInvoiceRef = lacaseRecTemp.getCusInvoiceRef().getValue();
                                        logger.info("custStatus :"+" "+custStatus);
                                        logger.info("cusInvoiceRef :"+" "+cusInvoiceRef);

                                        if (b2BStatusList1.contains(custStatus)&& partyRole.equals("BORROWER")) {
                                            hbInvDetsRecNew.setCustomerType("B2B");
                                            logger.info("b2BStatusList1.contains(custStatus) :"+" "+hbInvDetsRecNew);
                                        }
                                        if (b2CStatusList1.contains(custStatus)&& partyRole.equals("BORROWER")) {
                                            hbInvDetsRecNew.setCustomerType("B2C");
                                            logger.info("b2CStatusList1.contains(custStatus) :"+" "+hbInvDetsRecNew);
                                        }
                                        //   if (payFinalDemandFlag){
                                        customerset.setCustomerId(custNo);
                                        customerset.setRegisterId(custRec.getLocalRefField("HUS.REGISTER.ID").getValue());
                                        customerset.setDbtRestStatus(custRec.getLocalRefField("DBT.REST.STATUS").getValue());
                                        logger.info("after customerset formation :"+" "+customerset);
                                        //  }
                                        hbInvDetsRecNew.setCustomerRef(cusInvoiceRef);
                                        hbInvDetsRecNew.addCustomerId(customerset);
                                        logger.info("hbInvDetsRecNew :"+" "+hbInvDetsRecNew);
                                    } // send voice if
                                } catch (Exception e) {
                                    // Exception
                                }

                            } // Project loop
                            // Customer
                        }

                        lineIdSet = new LineIdClass();
                        if (accPropFlag || prinIntPropFlag || penIntPropFlag) {
                            lineIdSet.setLineId(String.valueOf(lineIdCnt));
                            lineIdSet.setAmount(orPropAmt);
                            logger.info("Executing accPropFlag || prinIntPropFlag || penIntPropFlag) IF condition :"+" "+lineIdSet);
                        }

                        if (chgIntPropFlag) {
                            logger.info("if chgIntPropFlag is available");
                            if (!enterChgflag) {
                                logger.info("if enterChgflag not equal to null");
                                tempLineChgCnt = lineIdCnt;
                                tempListCnt = billCnt;
                                logger.info("tempLineChgCnt :"+" "+tempLineChgCnt);
                                logger.info("tempListCnt :"+" "+tempListCnt);
                            }
                            if (!orPropAmt.isEmpty()) {
                                logger.info("if orPropAmt is not empty");
                                double newPropAmt1 = Double.parseDouble(orPropAmt);
                                newChgPropAmt = Double.sum(newChgPropAmt, newPropAmt1);
                                logger.info("newPropAmt1 :"+" "+newPropAmt1);
                                logger.info("newChgPropAmt :"+" "+newChgPropAmt);
                            }
                            lineIdSet.setLineId(String.valueOf(tempLineChgCnt));
                            lineIdSet.setAmount(String.valueOf(newChgPropAmt));
                            enterChgflag = true;
                            logger.info("lineIdSet :"+" "+lineIdSet);
                            logger.info("enterChgflag is set to true");
                        }
                        if (costIntPropFlag) {
                            logger.info("if costIntPropFlag is available");
                            if (!enterCostflag) {
                                logger.info("if enterCostflag not equal to null");
                                tempLineCostCnt = lineIdCnt;
                                tempListCnt = billCnt;
                                logger.info("tempLineCostCnt :"+" "+tempLineCostCnt);
                                logger.info("tempListCnt :"+" "+tempListCnt);
                            }
                            if (!orPropAmt.isEmpty()) {
                                logger.info("if orPropAmt is not empty");
                                double newPropAmt1 = Double.parseDouble(orPropAmt);
                                newCostPropAmt = Double.sum(newCostPropAmt, newPropAmt1);
                                logger.info("newPropAmt1 :"+" "+newPropAmt1);
                                logger.info("newCostPropAmt :"+" "+newCostPropAmt);
                            }
                            lineIdSet.setLineId(String.valueOf(tempLineCostCnt));
                            lineIdSet.setAmount(String.valueOf(newCostPropAmt));
                            enterCostflag = true;
                            logger.info("lineIdSet :"+" "+lineIdSet);
                            logger.info("enterCostflag is set to true");
                        }
                        // Condition to set lineset for property not
                        // in defined PARAM
                        if ((!accPropFlag) && (!prinIntPropFlag) && (!penIntPropFlag) && (!chgIntPropFlag)&& (!costIntPropFlag)) {
                            logger.info("Defaulting prop name as no desc in PARAM table");
                            amtType = propertyName; // defaulting prop name as no desc in PARAM table
                            lineIdSet.setLineId(String.valueOf(lineIdCnt));
                            lineIdSet.setAmount(orPropAmt);
                            logger.info("lineIdSet :"+" "+lineIdSet);
                        }

                        arrSet.setArrangementId(billArrId);
                        lineIdSet.setAmountType(amtType);
                        lineIdSet.setBillId(billId);
                        logger.info("setting arrid in arrSet :"+" "+arrSet);
                        logger.info("amt type and billid in lineIdSet :"+" "+lineIdSet);
                        if (chgIntPropFlag || costIntPropFlag) {
                            arrSet.setLineId(lineIdSet, tempListCnt);
                            logger.info("setting lineid in arrSet :"+" "+arrSet);
                        } else {
                            arrSet.addLineId(lineIdSet);
                            logger.info("adding line id in arrSet :"+" "+arrSet);
                        }

                        hbInvDetsRecNew.setArrangementId(arrSet, existArrSize);
                        logger.info("existArrSize:"+" "+existArrSize);
                        logger.info("setting arr id in hbInvDetsRecNew :"+" "+hbInvDetsRecNew);
                        if (!orPropAmt.isEmpty()) {
                            logger.info("if orPropAmt is not empty :"+" "+orPropAmt);
                            double newPropAmt1 = Double.parseDouble(orPropAmt);
                            amtAdd = Double.sum(amtAdd, newPropAmt1);
                            logger.info("newPropAmt1 :"+" "+newPropAmt1);
                            logger.info("amtAdd :"+" "+amtAdd);
                        }
                        lineIdCnt++;
                        billCnt++;
                        logger.info("incrementing lineIdCnt :"+" "+lineIdCnt);
                        logger.info("incrementing billCnt :"+" "+billCnt);
                        logger.info("hbInvDetsRecNew :"+" "+hbInvDetsRecNew.toString());

                        //
                    }
                } // property for loop end

                billRemCnt++;
                logger.info("incrementing billRemCnt :"+" "+billRemCnt);
                String billIdexit;
                try {
                    billIdexit = billAllIds.split("\\*")[billRemCnt];
                    billLast = false;
                    logger.info("billIdexit :"+" "+billIdexit);
                } catch (Exception e) {
                    billLast = true;
                }
                logger.info("billLast flag set to :"+" "+billRemCnt);

            } // Bill group loop end
            existArrSize++;
            logger.info("incrementing existArrSize :"+" "+existArrSize);
        } // Arr Grp end
        // Ofs Initialise

        double newTotAmt = 0;
        newTotAmt = Double.sum(amtAdd, totAmt);
        logger.info("amtAdd :"+" "+amtAdd);
        logger.info("totAmt :"+" "+totAmt);
        logger.info("newTotAmt :"+" "+newTotAmt);
        //


        hbInvDetsRecNew.setTotalAmount(String.valueOf(df.format(newTotAmt)));
        hbInvDetsRecofs = hbInvDetsRecNew;

        // updating leftover table
        String invIdtype = hbInvoiceDetsId.split("\\.")[0];

        //Logger for Leftover logic starts
        if (invIdtype.equalsIgnoreCase("I")){
            logger.info("invIdtype for leftover check :"+" "+invIdtype);
            EbHbInvoiceLeftoverRecord invLeftOverRecExist = null;
            EbHbInvoiceLeftoverRecord invLeftOverRecNew = null;
            EbHbInvoiceLeftoverRecord invLeftOverRecofs = null;
            double totOsAmt = 0.0;
            double osTotAmtint = 0.0;
            boolean leftOverExistFlag = false;
            logger.info("init leftOverExistFlag :"+" "+leftOverExistFlag);
            String invoiceTotAmt = hbInvDetsRecNew.getTotalAmount().toString();
            double currInvTotAmt = Double.parseDouble(invoiceTotAmt);
            logger.info("currInvTotAmt : total amt for the current invoice record :"+" "+currInvTotAmt);
            try{
                invLeftOverRecExist = new EbHbInvoiceLeftoverRecord(da.getRecord("EB.HB.INVOICE.LEFTOVER", id));
                leftOverExistFlag = true;
                logger.info("exis leftover record array :"+" "+invLeftOverRecExist);
                logger.info("if leftover record for the case id is already available :"+" "+leftOverExistFlag);
            }catch (Exception e) {
                invLeftOverRecNew = new EbHbInvoiceLeftoverRecord();
                leftOverExistFlag = false;
                logger.info("new leftover record array :"+" "+invLeftOverRecNew);
                logger.info("if leftover record for the case id is not available :"+" "+leftOverExistFlag);
            }
            double pInvMinAmt = 0.0;
            String paramLeftOverDesc = "";
            try {
                invParamRec = new EbHbInvoiceParamRecord(da.getRecord("EB.HB.INVOICE.PARAM", "SYSTEM"));
                List<InvMinAmountCcyClass> lstInvMinAmt = invParamRec.getInvMinAmountCcy();
                logger.info("lstInvMinAmt :"+" "+lstInvMinAmt);
                int lstInvMinAmtCnt = lstInvMinAmt.size();
                logger.info("lstInvMinAmtCnt :"+" "+lstInvMinAmtCnt);
                paramLeftOverDesc = invParamRec.getLeftoverDesc().getValue();
                logger.info("paramLeftOverDesc :"+" "+paramLeftOverDesc);
                for (int amtCnt = 0;amtCnt< lstInvMinAmtCnt;amtCnt++) {
                    String invParamCcy = lstInvMinAmt.get(amtCnt).getInvMinAmountCcy().getValue();
                    logger.info("invParamCcy :"+" "+invParamCcy);
                    double invParamMinAmt = 0.0;
                    String invminAmount = lstInvMinAmt.get(amtCnt).getInvMinAmount().getValue();
                    if(!invminAmount.equals("")){
                        invParamMinAmt = Double.parseDouble(invminAmount);
                        logger.info("invParamMinAmt :"+" "+invParamMinAmt);
                    }
                    if (invParamCcy.equals(hbInvDetsRecNew.getCurrency().getValue())) {
                        pInvMinAmt = invParamMinAmt;
                        logger.info(" pInvMinAmt :"+" "+ pInvMinAmt);
                    }
                }
                logger.info("aaInvParmFlag is set to true as SYSTEM record is available under EB.HB.INVOICE.PARAM  table ");
            } catch (Exception e) {
                throw new T24CoreException("SYSTEM record missing in PARAM file");
            }

            String billInvId = "";
            double addVal = 0;
            int billInvCnt = 0;
            int cntlineList = 0;
            double finTotAmt = Double.sum(currInvTotAmt, addVal);
            logger.info("finTotAmt- total amount for the first invoice :"+" "+finTotAmt);
            List<String> billIds = new ArrayList<String>();
            logger.info("billIds array initialised :"+" "+billIds);
            InvoiceIdClass incIdRec = new InvoiceIdClass();
            InvoiceIdClass newIncIdRec = new InvoiceIdClass();
            logger.info("incIdRec array initialised :"+" "+incIdRec);
            List<ArrangementIdClass> arrList = null;
            List<LineIdClass> lineList = null;
            if (!leftOverExistFlag) {
                logger.info("inside IF because leftover record for the case id is not available :"+" "+leftOverExistFlag);
                arrList = hbInvDetsRecNew.getArrangementId();
                logger.info("list of arr ids taken from the current invoice record:"+" "+arrList);
                logger.info("arrList :"+" "+arrList);
                if (!arrList.isEmpty()){
                    for (ArrangementIdClass arrRec : arrList) {
                        logger.info("looping through each arrangement : arrRec:"+" "+arrRec);
                        lineList = arrRec.getLineId();
                        logger.info("list of line ids taken from the current invoice record for the resp arrangement:"+" "+lineList);
                        cntlineList = lineList.size();
                        logger.info("count of line ids taken from the current invoice record for the resp arrangement:"+" "+cntlineList);
                        if (!lineList.isEmpty()){
                            for (LineIdClass lineRec : lineList) {
                                logger.info("looping through each line id for the arr : lineRec:"+" "+lineRec);
                                billInvId = lineRec.getBillId().getValue();
                                logger.info("getting the bill id under the line id"+" "+billInvId);
                                int currBillId = billIds.indexOf(billInvId);
                                logger.info("currBillId :"+" "+currBillId);
                                if (currBillId == -1){
                                    try{
                                        incIdRec.setBillId(billInvId, billInvCnt);
                                        billIds.add(billInvId);
                                        billInvCnt++;
                                    }catch(Exception e){
                                        //Exception e
                                    }
                                }
                            }//lineset loop
                        }//lineid list array 
                    }//inv arr loop
                }//arr list array 
                incIdRec.setInvoiceId(hbInvoiceDetsId);
                logger.info("invoice set in leftover recrd formed for the first time :"+" "+incIdRec);
                invLeftOverRecNew.addInvoiceId(incIdRec);
                logger.info("invLeftOverRecNew :leftover recrd formed for the first time :"+" "+invLeftOverRecNew);
                invLeftOverRecofs = invLeftOverRecNew;
                logger.info("invLeftOverRecofs - first time formation :"+" "+invLeftOverRecofs);
            } else {
                logger.info("inside IF because leftover record for the case id is already available :"+" "+leftOverExistFlag);
                List<InvoiceIdClass> lstLeftInv = invLeftOverRecExist.getInvoiceId();
                logger.info("list of all invoice ids:"+" "+lstLeftInv);
                int cntlstLeftInv = lstLeftInv.size();
                logger.info("count of invoice id in leftover:"+" "+cntlstLeftInv);
                for (int k=0; k<cntlstLeftInv; k++){
                    String newInv  =lstLeftInv.get(k).getNewInvoice().getValue();
                    logger.info("new invoice field for the respective mv set:"+" "+newInv);
                    if (newInv.isEmpty()){
                        logger.info("when newInv is empty");
                        List<TField> leftBillIds = lstLeftInv.get(k).getBillId();
                        logger.info("bills under the invoice:"+" "+leftBillIds);
                        int cntleftBillIds = leftBillIds.size();
                        logger.info("count of all bill ids under invoice:"+" "+cntleftBillIds);
                        for (int j=0; j<cntleftBillIds; j++){
                            String billLeftId = leftBillIds.get(j).getValue();
                            try{
                                logger.info("looping through each bill id");
                                AaBillDetailsRecord billDetsRec = new AaBillDetailsRecord(da.getRecord("AA.BILL.DETAILS", billLeftId));
                                logger.info("billDetsRec :"+" "+billDetsRec);
                                String osTotAmt = billDetsRec.getOsTotalAmount().getValue();
                                logger.info("osTotAmt :"+" "+osTotAmt);
                                osTotAmtint = Double.parseDouble(osTotAmt);
                                logger.info("osTotAmtint :"+" "+osTotAmtint);
                                totOsAmt  = Double.sum(totOsAmt, osTotAmtint);
                                logger.info("totOsAmt :"+" "+totOsAmt);
                            }catch(Exception e){
                                //Exception e
                            }
                        }
                    }
                }
                logger.info("before adding the total bill amount to the existing invoice amt");
                logger.info("totOsAmt :"+" "+totOsAmt);
                logger.info("finTotAmt :"+" "+finTotAmt);
                finTotAmt = Double.sum(totOsAmt, finTotAmt);
                logger.info("after adding the amounts :"+" "+finTotAmt);
            }

            if ((finTotAmt<=pInvMinAmt)&& (!leftOverExistFlag)){
                logger.info("if finTotAmt<=pInvMinAmt and there is no leftover record");
                postLeftOverOfs(id, transactionData, records, invLeftOverRecofs);
            }

            if ((finTotAmt<=pInvMinAmt)&& (leftOverExistFlag)){
                logger.info("if finTotAmt<=pInvMinAmt and there is leftover record");
                arrList = hbInvDetsRecNew.getArrangementId();
                logger.info("arrList :"+" "+arrList);
                if (!arrList.isEmpty()){
                    for (ArrangementIdClass arrRec : arrList) {
                        lineList = arrRec.getLineId();
                        cntlineList = lineList.size();
                        logger.info("lineList :"+" "+lineList);
                        logger.info("cntlineList :"+" "+cntlineList);
                        if (!lineList.isEmpty()){
                            for (LineIdClass lineRec : lineList) {
                                logger.info("lineRec :"+" "+lineRec);
                                billInvId = lineRec.getBillId().getValue();
                                logger.info("billId :"+" "+billInvId);
                                int currBillId = billIds.indexOf(billInvId);
                                logger.info("currBillId :"+" "+currBillId);
                                /*  List<InvoiceIdClass> lstLeftInv = invLeftOverRecExist.getInvoiceId();
                                int cntlstLessLeftInv = lstLeftInv.size();
                                logger.info("lstLeftInv :"+" "+lstLeftInv);
                                logger.info("cntlstLessLeftInv :"+" "+cntlstLessLeftInv);*/
                                logger.info("before setting the new mv set after newinv field is not empty");
                                //  invLeftOverRecExist.getInvoiceId(cntlstLessLeftInv).setInvoiceId(hbInvoiceDetsId);
                                logger.info("after setting the new mv set after newinv field is not empty");
                                if (currBillId == -1){
                                    try{
                                        newIncIdRec.setBillId(billInvId, billInvCnt);
                                        billIds.add(billInvId);
                                        billInvCnt++;
                                    }catch(Exception e){
                                        //Exception e
                                    }
                                }
                            }//lineset loop
                        }//lineid list array 
                    }//inv arr loop
                }//arr list array 
                newIncIdRec.setInvoiceId(hbInvoiceDetsId);
                logger.info("invoice set in leftover recrd formed for existing leftover record :"+" "+newIncIdRec);
                invLeftOverRecExist.addInvoiceId(newIncIdRec);
                logger.info("forming the entire array where new mv set is added after newinv field is not empty:"+" "+invLeftOverRecExist);
                invLeftOverRecofs = invLeftOverRecExist;
                logger.info("incIdRec :"+" "+incIdRec);
                logger.info("invLeftOverRecNew :"+" "+invLeftOverRecExist);
                logger.info("Posting Invoice leftover details :");
                logger.info("if existing invLeftOverRecofs :"+" "+invLeftOverRecofs);
                postLeftOverOfs(id, transactionData, records, invLeftOverRecofs);
                logger.info("invLeftOverRecofs ofs formation when lesser:"+" "+invLeftOverRecofs);
                logger.info("Posting Invoice leftover details when finTotAmt<=pInvMinAmt and there is leftover record");
            }else{
                if ((finTotAmt>pInvMinAmt)&& (leftOverExistFlag)){
                    sInvFlag = true;
                    int cntCurrlineList = 0;
                    logger.info("if finTotAmt>pInvMinAmt and there is leftover record");
                    logger.info("setting newinv field where totalamt is greater than inv min amt");
                    List<InvoiceIdClass> lstLeftInvRec = invLeftOverRecExist.getInvoiceId();
                    int cntlstExisLeftInv = lstLeftInvRec.size();
                    for (int m=0; m<cntlstExisLeftInv; m++){
                        String exisnewInv = invLeftOverRecExist.getInvoiceId(m).getNewInvoice().getValue();
                        if (exisnewInv.isEmpty()){
                            invLeftOverRecExist.getInvoiceId(m).setNewInvoice(hbInvoiceDetsId);
                        }
                    }
                    List<ArrangementIdClass> currArrList = hbInvDetsRecNew.getArrangementId();
                    if (!currArrList.isEmpty()){
                        for (ArrangementIdClass arrCurrRec : currArrList) {
                            logger.info("looping through each arrangement : arrCurrRec:"+" "+arrCurrRec);
                            List<LineIdClass> lineCurrList = arrCurrRec.getLineId();
                            logger.info("list of line ids taken from the current invoice record for the resp arrangement:"+" "+lineCurrList);
                            cntCurrlineList = lineCurrList.size();
                        }
                    }
                    hbInvDetsRecNew.setTotalAmount(String.valueOf(df.format(finTotAmt)));
                    if (totOsAmt>0.0){
                        ArrangementIdClass invDetsArrId = new ArrangementIdClass();
                        LineIdClass invDetsLineId = new LineIdClass();
                        invDetsArrId.setArrangementId("");
                        invDetsLineId.setLineId(String.valueOf(cntCurrlineList+1));
                        invDetsLineId.setBillId("");
                        invDetsLineId.setAmountType(paramLeftOverDesc);
                        invDetsLineId.setAmount(Double.toString(totOsAmt));
                        invDetsArrId.addLineId(invDetsLineId);
                        hbInvDetsRecNew.addArrangementId(invDetsArrId);
                        invLeftOverRecofs = invLeftOverRecExist;
                        logger.info("invLeftOverRecofs :"+" "+invLeftOverRecofs);
                        logger.info("hbInvDetsRecNew array with new field set :"+" "+hbInvDetsRecNew);
                        postLeftOverOfs(id, transactionData, records, invLeftOverRecofs);
                    }
                    logger.info("invLeftOverRecofs ofs formation when greater:"+" "+invLeftOverRecofs);
                    logger.info("Posting Invoice leftover details when finTotAmt>pInvMinAmt and there is leftover record:");
                }else{
                    if ((finTotAmt>pInvMinAmt)&& (!leftOverExistFlag)){
                        sInvFlag = true;
                    }
                }
            }
        } // invType loop
        trans.setFunction("INPUT");
        trans.setNumberOfAuthoriser("0");
        trans.setSourceId("HUS.LOAN");
        trans.setVersionId(INVOICEDETSVERSION);
        trans.setTransactionId(hbInvoiceDetsId);
        logger.info("invoice details id :"+" "+hbInvoiceDetsId);
        logger.info("final inv record posting - hbInvDetsRecNew record :"+" "+hbInvDetsRecNew);
        return sInvFlag;
    }// hbOfs
    // method

    /**
     * @param id
     * @param transactionData
     * @param records
     * @param invLeftOverRecofs
     */
    private void postLeftOverOfs(String id, List<TransactionData> transactionData, List<TStructure> records,
            EbHbInvoiceLeftoverRecord invLeftOverRecofs) {
        Logger logger = Logger.getLogger("HusBatInvoicePreparation-postLeftOverOfs process");
        try {

            FileHandler fileHandler = new FileHandler("../../../../../srv/Temenos/TAFJ/log/invprepPostLeftOverOfs.txt");
            logger.addHandler(fileHandler);
            SimpleFormatter formatter = new SimpleFormatter();
            fileHandler.setFormatter(formatter);
        } catch (SecurityException e ) {

        } catch (IOException e) {
        }
        logger.info("inside postLeftOverOfs method");
        TransactionData transHbOfs = new TransactionData();
        transHbOfs.setVersionId("EB.HB.INVOICE.LEFTOVER,HUS.OFS");
        transHbOfs.setFunction(function);
        transHbOfs.setSourceId(ofsSrc);
        transHbOfs.setNumberOfAuthoriser("0");
        transHbOfs.setCompanyId("NO0010001");
        transHbOfs.setTransactionId(id);
        transactionData.add(transHbOfs);
        records.add(invLeftOverRecofs.toStructure());
    }

} // class
