package com.husbanken.loanmain.invoices;

import java.io.IOException;
import java.util.List;
import java.util.logging.FileHandler;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

import com.temenos.api.TField;
import com.temenos.api.TStructure;
import com.temenos.api.exceptions.T24IOException;
import com.temenos.t24.api.arrangement.accounting.Contract;
import com.temenos.t24.api.complex.aa.activityhook.ArrangementContext;
import com.temenos.t24.api.complex.aa.activityhook.TransactionData;
import com.temenos.t24.api.hook.arrangement.ActivityLifecycle;
import com.temenos.t24.api.records.aaaccountdetails.AaAccountDetailsRecord;
import com.temenos.t24.api.records.aaarrangement.AaArrangementRecord;
import com.temenos.t24.api.records.aaarrangementactivity.AaArrangementActivityRecord;
import com.temenos.t24.api.records.aaprddesaccount.AaPrdDesAccountRecord;
import com.temenos.t24.api.records.aaproductcatalog.AaProductCatalogRecord;
import com.temenos.t24.api.records.customer.CustomerRecord;
import com.temenos.t24.api.system.DataAccess;
import com.temenos.t24.api.tables.ebhbarrtodaybills.EbHbArrTodayBillsRecord;
import com.temenos.t24.api.tables.ebhbarrtodaybills.EbHbArrTodayBillsTable;
import com.temenos.t24.api.tables.ebhuslacase.EbHusLaCaseRecord;
import com.temenos.t24.api.tables.ebhuslacase.ProjectPartyClass;

/**
 * /* TODO: Document me!
 *
 * @author 10673048
 * 
 *         Developed For : LoanMaintenance_LM04 - Invoices and credit notes
 * 
 *         Attached to : AA.PRD.DES.ACTIVITY.API condition
 * 
 *         Attached As : Post routine
 * 
 *         Description : This Post routine will get today’s bill details and
 *         update EB.HB.INVOICE.DETAILS for online arrangements & used to update EB.HB.ARR.TODAY.BILLS during COB
 */

public class HusInvoicePreparationLogic extends ActivityLifecycle {

    @Override
    public void postCoreTableUpdate(AaAccountDetailsRecord accountDetailRecord,
            AaArrangementActivityRecord arrangementActivityRecord, ArrangementContext arrangementContext,
            AaArrangementRecord arrangementRecord, AaArrangementActivityRecord masterActivityRecord,
            TStructure productPropertyRecord, AaProductCatalogRecord productRecord, TStructure record,
            List<TransactionData> transactionData, List<TStructure> transactionRecord) {
        // TODO Auto-generated method stub

        Logger logger = Logger.getLogger("InvoicePrepLogic-main process");
        try {

            FileHandler fileHandler = new FileHandler("../../../../../srv/Temenos/TAFJ/log/InvoicePrepLogicLog.txt");
            logger.addHandler(fileHandler);
            SimpleFormatter formatter = new SimpleFormatter();
            fileHandler.setFormatter(formatter);
        } catch (SecurityException e ) {

        } catch (IOException e) {
        }

        TField actEffDate = arrangementActivityRecord.getEffectiveDate();
        logger.info("actEffDate :"+" "+actEffDate);
        String actEffDateVal = actEffDate.toString();
        String arrTodayBillsId = "";
        String arrId = "";
        String hbCaseId = "";
        if(arrangementContext.getActivityStatus().equalsIgnoreCase("AUTH")) {
            logger.info("ActivityStatus is AUTH");

            Contract contractRec = new Contract(this);
            contractRec.setContractId(arrangementContext.getArrangementId());

            arrId = arrangementActivityRecord.getArrangement().getValue();

            String acprop = contractRec.getPropertyIdsForPropertyClass("ACCOUNT").get(0);
            logger.info("Account property :"+" "+acprop);
            AaPrdDesAccountRecord aaPrdDesAccountRec = contractRec.getAccountCondition(acprop);
            logger.info("AA.PRD.DES.ACCOUNT record :"+" "+aaPrdDesAccountRec);
            hbCaseId = aaPrdDesAccountRec.getLocalRefField("HB.CASE.ID").getValue();
            logger.info("HbCaseID :"+" "+hbCaseId);
            arrTodayBillsId = hbCaseId+"."+arrId;
            logger.info("arrTodayBillsId :"+" "+arrTodayBillsId);
            
            DataAccess da = new DataAccess(this);
            EbHusLaCaseRecord lacaseRec = new EbHusLaCaseRecord(da.getRecord("EB.HUS.LA.CASE", hbCaseId));
            logger.info("lacaseRec :"+" "+lacaseRec);
            String sendToColl = lacaseRec.getSendToCollection().getValue();
            logger.info("sendToColl :"+" "+sendToColl);

            // LM05-Added

            int caseCustCnt = lacaseRec.getProjectParty().size();
            logger.info("Project Party count :"+" "+caseCustCnt);
            int negotiationCnt = 0;
            List<ProjectPartyClass> prjPartyList = lacaseRec.getProjectParty();
            logger.info("Project party List :"+" "+prjPartyList);

            for (ProjectPartyClass prjPartyRec : prjPartyList) {
                String custNo = prjPartyRec.getProjectParty().getValue();
                logger.info("Project party customer number :"+" "+custNo);
                try {
                    CustomerRecord custRec = new CustomerRecord(da.getRecord("CUSTOMER", custNo));
                    logger.info("custRec :"+" "+custRec);
                    String dbtRestStatus = custRec.getLocalRefField("DBT.REST.STATUS").getValue();
                    logger.info("dbtRestStatus :"+" "+dbtRestStatus);
                    if ((!dbtRestStatus.isEmpty()) && (dbtRestStatus.equalsIgnoreCase("NEGOTIATION"))) {
                        negotiationCnt++;
                        logger.info("incrementing negotiationCnt when dbtRestStatus is equal to NEGOTIATION :"+" "+negotiationCnt);
                    }
                } catch (Exception e) {
                    // Exception
                }
            } // Project loop
            if (negotiationCnt == caseCustCnt) {
                logger.info("routine is terminated as the count in variable negotiationCnt is equal to caseCustCnt variable ");
                return;
            }

            // LM05-Added
            if ((sendToColl.equalsIgnoreCase("Y"))
                    || (arrangementContext.getCurrentActivity().equalsIgnoreCase("LENDING-ISSUEBILL-OVERDUEFEE"))
                    || (arrangementContext.getCurrentActivity().equalsIgnoreCase("LENDING-ISSUEBILL-COLLECTIONFEE"))
                    || (arrangementContext.getCurrentActivity().equalsIgnoreCase("LENDING-ISSUEBILL-INVOICEFEE"))
                    || (arrangementContext.getCurrentActivity().equalsIgnoreCase("LENDING-CAPTURE.BILL-INVOICEFEE"))) {
                logger.info("routine is terminated as sendToColl is equal to Y and Current activity is either LENDING-CHARGE-OVERDUEFEE or LENDING-CHARGE-COLLECTIONFEE");
                return;
            } // send Yes

            EbHbArrTodayBillsTable ebHbArrTodayBillsTable = new EbHbArrTodayBillsTable(this);
            EbHbArrTodayBillsRecord ebHbArrTodayBillsRec = new EbHbArrTodayBillsRecord(this);
            ebHbArrTodayBillsRec.setActDate(actEffDateVal);
            try {
                logger.info("arrTodayBillsId :"+" "+arrTodayBillsId);
                ebHbArrTodayBillsTable.write(arrTodayBillsId, ebHbArrTodayBillsRec);
                logger.info("ebHbArrTodayBillsRec :"+" "+ebHbArrTodayBillsRec);
            } catch (T24IOException e1) {
                // Logger exception
            }  
        }
    }

}