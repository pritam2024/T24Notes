package com.husbanken.loanmain.invoices;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

import com.temenos.api.TDate;
import com.temenos.api.TField;
import com.temenos.api.TStructure;
import com.temenos.api.exceptions.T24CoreException;
import com.temenos.t24.api.arrangement.accounting.Contract;
import com.temenos.t24.api.complex.aa.activityhook.ArrangementContext;
import com.temenos.t24.api.complex.aa.activityhook.TransactionData;
import com.temenos.t24.api.hook.arrangement.ActivityLifecycle;
import com.temenos.t24.api.records.aaaccountdetails.AaAccountDetailsRecord;
import com.temenos.t24.api.records.aaaccountdetails.BillIdClass;
import com.temenos.t24.api.records.aaaccountdetails.BillPayDateClass;
import com.temenos.t24.api.records.aaarrangement.AaArrangementRecord;
import com.temenos.t24.api.records.aaarrangementactivity.AaArrangementActivityRecord;
import com.temenos.t24.api.records.aabilldetails.AaBillDetailsRecord;
import com.temenos.t24.api.records.aabilldetails.PaymentTypeClass;
import com.temenos.t24.api.records.aabilldetails.PropertyClass;
import com.temenos.t24.api.records.aaproductcatalog.AaProductCatalogRecord;
import com.temenos.t24.api.records.account.AccountRecord;
import com.temenos.t24.api.records.customer.CustomerRecord;
import com.temenos.t24.api.system.DataAccess;
import com.temenos.t24.api.tables.ebhbinvoicedetails.ArrangementIdClass;
import com.temenos.t24.api.tables.ebhbinvoicedetails.CustomerIdClass;
import com.temenos.t24.api.tables.ebhbinvoicedetails.EbHbInvoiceDetailsRecord;
import com.temenos.t24.api.tables.ebhbinvoicedetails.LineIdClass;
import com.temenos.t24.api.tables.ebhbinvoiceparam.EbHbInvoiceParamRecord;
import com.temenos.t24.api.tables.ebhbunpaidinvoice.EbHbUnpaidInvoiceRecord;
import com.temenos.t24.api.tables.ebhuslacase.EbHusLaCaseRecord;
import com.temenos.t24.api.tables.ebhuslacase.ProjectPartyClass;

/**
 * /* TODO: Document me!
 *
 * @author 10673048
 * 
 *         Developed For : LoanMaintenance_LM04 - Invoices and credit notes
 * 
 *         Attached to : AA.PRD.DES.ACTIVITY.API condition
 * 
 *         Attached As : Post routine
 * 
 *         Description : This Post routine will trigger during reverse & replay action and
 *         update EB.HB.INVOICE.DETAILS accordingly.
 */
public class HusInvoiceReversalLogic extends ActivityLifecycle {
    private static final String INVDETAILSVERSION = "EB.HB.INVOICE.DETAILS,HUS.OFS";
    private static DecimalFormat df = new DecimalFormat("0.00");

    @Override
    public void postCoreTableUpdate(AaAccountDetailsRecord accountDetailRecord,
            AaArrangementActivityRecord arrangementActivityRecord, ArrangementContext arrangementContext,
            AaArrangementRecord arrangementRecord, AaArrangementActivityRecord masterActivityRecord,
            TStructure productPropertyRecord, AaProductCatalogRecord productRecord, TStructure record,
            List<TransactionData> transactionData, List<TStructure> transactionRecord) {
        // TODO Auto-generated method stub
        DataAccess da = new DataAccess(this);
 
        List<PropertyClass> propertyList = null;
        List<TField> accPropertyLst = null;
        List<TField> prinIntPropertyLst = null;
        List<TField> penalIntPropertyLst = null;
        EbHbInvoiceParamRecord invParamRec = null;
        String accPropertyLst1 = "";
        String prinIntPropertyLst1 = "";
        String penalIntPropertyLst1 = "";
        String b2BStatusList1 = "";
        String b2CStatusList1 = "";
        try {
            invParamRec = new EbHbInvoiceParamRecord(da.getRecord("EB.HB.INVOICE.PARAM", "SYSTEM"));

            accPropertyLst1 = invParamRec.getAccountProperty().toString();
            prinIntPropertyLst1 = invParamRec.getPrincipalIntProperty().toString();
            penalIntPropertyLst1 = invParamRec.getPenaltyIntProperty().toString();
            accPropertyLst = invParamRec.getAccountProperty();
            prinIntPropertyLst = invParamRec.getPrincipalIntProperty();
            penalIntPropertyLst = invParamRec.getPenaltyIntProperty();
            b2BStatusList1 = invParamRec.getB2bCustomerStatus().toString();
            b2CStatusList1 = invParamRec.getB2cCustomerStatus().toString();
        } catch (Exception e) {
            throw new T24CoreException("SYSTEM record missing in PARAM file");
        }
             
        String actStatus = arrangementContext.getActivityStatus();
        if (actStatus.equals("AUTH-REV")) {
        
            String arrId = arrangementContext.getArrangementId();
            String accountId = arrangementContext.getLinkedAccount();
            String actEffDate = arrangementContext.getActivityEffectiveDate();
            Contract contractRec = new Contract(this);
            contractRec.setContractId(arrId);
 
            // Logic to get present bils
            List<String> billPresentIds = new ArrayList<String>();
            TDate actEffDateNew = new TDate(actEffDate);
            billPresentIds = contractRec.getBillIdsForDate(actEffDateNew);
  
            try {
                AccountRecord accRec = new AccountRecord(da.getRecord("ACCOUNT", accountId));
                String hbCaseId = accRec.getLocalRefField("HB.CASE.ID").getValue();
                EbHbUnpaidInvoiceRecord unpaidInvRec = new EbHbUnpaidInvoiceRecord(
                        da.getRecord("EB.HB.UNPAID.INVOICE", hbCaseId));
                // Logic to get old bills
                List<TField> invDetsIdList = unpaidInvRec.getInvoiceDetId();
                String invDetsIdListCheck = unpaidInvRec.getInvoiceDetId().toString();
                String hbInvoiceDetstypeId = "";
                for (TField invDetsId : invDetsIdList) {
                    List<String> billoldIds = new ArrayList<String>();
                    String invDetailsId = invDetsId.toString();
                    hbInvoiceDetstypeId = invDetailsId;
                    String invDetsDate = invDetailsId.split("\\.")[2];
                    if (!actEffDate.equalsIgnoreCase(invDetsDate)) {
                        continue;
                    }    
                    EbHbInvoiceDetailsRecord invDetailsRec = new EbHbInvoiceDetailsRecord(
                            da.getRecord("EB.HB.INVOICE.DETAILS", invDetailsId));
                    String invStatus = invDetailsRec.getStatus().getValue();
 
                    if ((!invStatus.isEmpty()) && ((!invStatus.equalsIgnoreCase("NEW")) && (!invStatus.equalsIgnoreCase("SENDING-GET-CHANNEL"))&& (!invStatus.equalsIgnoreCase("FAILED-GET-CHANNEL")))) {
                        invDetailsRec.setStatus("NEW");
                        invDetailsRec.setType("CREDIT.NOTE");
                    } else { // proceed only if invStatus eq NEW
                        List<ArrangementIdClass> arrList = invDetailsRec.getArrangementId();
  
                        int arrSize = 0;
                        int lineSize = 0;
                        int linereorderSize = 1;
                        int linereorderSizeCnt = 0;
                        String billAmt = "";
                        double newTotAmt = 0;
                        String amtType = "";
                        String orPropAmt = "";
                        double amtAdd = 0;
                        for (ArrangementIdClass arrRec : arrList) {
                            if (arrRec.getArrangementId().getValue().equalsIgnoreCase(arrId)) {
                                List<LineIdClass> lineList = arrRec.getLineId();
                                for (LineIdClass lineRec : lineList) {
                                    String billId = lineRec.getBillId().getValue();
                                    billoldIds.add(billId + "*" + invDetailsId);
                                    boolean revFlag = billPresentIds.contains(billId);
                                    billAmt = lineRec.getAmount().getValue();
                                    if ((!revFlag) && ((!invStatus.isEmpty()) && (invStatus.equalsIgnoreCase("NEW")
                                            || invStatus.equalsIgnoreCase("SENDING-GET-CHANNEL")
                                            || invStatus.equalsIgnoreCase("FAILED-GET-CHANNEL")))) {
                                        billAmt = "0";
                                          arrRec.removeLineId(lineSize);
                                    }

                                    double newPropAmt1 = Double.parseDouble(billAmt);
                                    newTotAmt = Double.sum(newTotAmt, newPropAmt1);

                                } // lineset loop
                                List<LineIdClass> lineListreOrder = arrRec.getLineId();

                                int billPresentIdsCnt = billPresentIds.size();
                                for (LineIdClass lineRec : lineListreOrder) {
                                    lineRec.setLineId(String.valueOf(linereorderSize));
                                    linereorderSize++;
                                    arrRec.setLineId(lineRec, linereorderSizeCnt);
                                    linereorderSizeCnt++;
                                } // linesetReorder loop

                                boolean accPropFlag = false;
                                boolean prinIntPropFlag = false;
                                boolean penIntPropFlag = false;
                                String husInvDetsIdType = "";
                                int billCnt = 0;
                                int lineIdCnt = 1;
                                boolean payFinalDemandFlag = false;

                                for (String billPresent : billPresentIds) {

                                    AaBillDetailsRecord billDetsRec = new AaBillDetailsRecord(
                                            da.getRecord("AA.BILL.DETAILS", billPresent));
                                    PaymentTypeClass paymentType = billDetsRec.getPaymentType(0); // taking
                                    // only
                                    // first
                                    // multivalue,

                                    String billCcy = billDetsRec.getCurrency().getValue();
                                    String billDate = paymentType.getBillDate().getValue();
                                    String paymentTypeVal = paymentType.getPaymentType().getValue();
                                    String paymentIndicator = billDetsRec.getPaymentIndicator().getValue();
                                    String paymentDate = billDetsRec.getPaymentDate().getValue();

                                    // Logic to decide AA.HB.INVOICE.DETAILS id
                                    // type
                                    boolean premiumProp = false;

                                    propertyList = billDetsRec.getProperty();

                                    husInvDetsIdType = "I"; // invoice type
                                    // Customer
                                    if (paymentTypeVal.equalsIgnoreCase("FINAL.DEMAND.PAYMENT")) {
                                        payFinalDemandFlag = true;
                                    }
                                    // Customer
                                    if ((paymentIndicator.equalsIgnoreCase("Debit")
                                            && paymentTypeVal.equalsIgnoreCase("PAYOFF$CURRENT"))
                                            || (paymentIndicator.equalsIgnoreCase("Debit")
                                                    && paymentTypeVal.equalsIgnoreCase("SPECIAL"))
                                            || (paymentIndicator.equalsIgnoreCase("Debit") && premiumProp)
                                            || (paymentIndicator.equalsIgnoreCase("Debit")
                                                    && paymentTypeVal.equalsIgnoreCase("LOSS.SHARING"))) {
                                        String husInvDetsPIdType = "P"; // payment
                                                                        // request
                                                                        // type
                                        hbInvoiceDetstypeId = husInvDetsPIdType + "." + hbCaseId + "." + billDate + "."
                                                + billCcy;

                                        husInvDetsIdType = "";
                                    }

                                    if (paymentIndicator.equalsIgnoreCase("Credit")) {
                                        if (!paymentTypeVal.equalsIgnoreCase("DISBURSEMENT.%")) {
                                            String husInvDetsCIdType = "C"; // Credit
                                                                            // Notes
                                                                            // type
                                            hbInvoiceDetstypeId = husInvDetsCIdType + "." + hbCaseId + "." + billDate
                                                    + "." + billCcy;
                                        }
                                        husInvDetsIdType = "";
                                    }
                                    if (husInvDetsIdType.equalsIgnoreCase("I")) {
                                        hbInvoiceDetstypeId = husInvDetsIdType + "." + hbCaseId + "." + billDate + "."
                                                + billCcy; // Invoice detail id
                                    }
                                    // check for newbill during reversal

                                    boolean newInvoicFlag = invDetsIdListCheck.contains(hbInvoiceDetstypeId);
                                    if ((!hbInvoiceDetstypeId.equalsIgnoreCase(invDetailsId)) && (!newInvoicFlag)) {
                                        // frame new invoice details only when
                                        // it is new bill & not available in
                                        // unpaid invoice

                                        invDetailsRec = new EbHbInvoiceDetailsRecord(this);
                                        arrRec = new ArrangementIdClass();
                                        invDetailsRec.setCaseId(hbCaseId);
                                        invDetailsRec.setInitialDueDate(paymentDate);
                                        invDetailsRec.setCurrency(billCcy);

                                        invDetailsRec.setIssueDate(actEffDate);
                                        invDetailsRec.setStatus("SENDING-GET-CHANNEL");

                                        if (!hbInvoiceDetstypeId.isEmpty()) {
                                            invDetailsRec.setType(hbInvoiceDetstypeId.split("\\.")[0]);
                                        }
                                        invDetailsRec.setDueDate(paymentDate);
                                        // *Customer

                                        EbHusLaCaseRecord lacaseRec = new EbHusLaCaseRecord(
                                                da.getRecord("EB.HUS.LA.CASE", hbCaseId));

                                        List<ProjectPartyClass> prjPartyList = lacaseRec.getProjectParty();

                                        CustomerIdClass customerset = null;
                                        for (ProjectPartyClass prjPartyRec : prjPartyList) {
                                            String custNo = prjPartyRec.getProjectParty().getValue();
                                            String sendInvoice = prjPartyRec.getSendInvoice().getValue();
                                            customerset = new CustomerIdClass();

                                            try {
                                                CustomerRecord custRec = new CustomerRecord(
                                                        da.getRecord("CUSTOMER", custNo));
                                                if (!sendInvoice.isEmpty()) {
                                                    String custStatus = custRec.getCustomerStatus().getValue();
                                                    String cusInvoiceRef = lacaseRec.getCusInvoiceRef().getValue();
                                                    if (b2BStatusList1.contains(custStatus)) {
                                                        invDetailsRec.setCustomerType("B2B");
                                                    }
                                                    if (b2CStatusList1.contains(custStatus)) {
                                                        invDetailsRec.setCustomerType("B2C");
                                                    }
                                                    if (payFinalDemandFlag || (sendInvoice.equalsIgnoreCase("N"))) {
                                                        customerset.setCustomerId(custNo);
                                                        customerset.setRegisterId(
                                                                custRec.getLocalRefField("HUS.REGISTER.ID").getValue());
                                                        customerset.setDbtRestStatus(
                                                                custRec.getLocalRefField("DBT.REST.STATUS").getValue());
                                                    }
                                                    invDetailsRec.setCustomerRef(cusInvoiceRef);
                                                    invDetailsRec.addCustomerId(customerset);
                                                } // send voice if
                                            } catch (Exception e) {
                                                // Exception
                                            }

                                        } // Project loop
                                          // Customer

                                    } // new bill gen
                                    for (PropertyClass propNames : propertyList) {
                                        String propertyName = propNames.getProperty().getValue();
                                        orPropAmt = propNames.getOrPropAmount().getValue();
                                        if (propertyName.equalsIgnoreCase("PREMIUM")) { // to
                                            // check
                                            // for
                                            // P
                                            // type
                                            premiumProp = true;
                                        }

                                        // Logic to decide AMOUNT.TYPE field
                                        // value
                                        amtType = "";
                                        accPropFlag = false;
                                        prinIntPropFlag = false;
                                        penIntPropFlag = false;

                                        if (!accPropertyLst.isEmpty()) {
                                            accPropFlag = accPropertyLst1.contains(propertyName);
                                            if (accPropFlag) {
                                                amtType = invParamRec.getAccountDesc().getValue();
                                            }
                                        }

                                        if (!prinIntPropertyLst.isEmpty()) {
                                            prinIntPropFlag = prinIntPropertyLst1.contains(propertyName);
                                            if (prinIntPropFlag) {
                                                amtType = invParamRec.getPrincipalIntDesc().getValue();
                                            }
                                        }
                                        if (!penalIntPropertyLst.isEmpty()) {
                                            penIntPropFlag = penalIntPropertyLst1.contains(propertyName);
                                            if (penIntPropFlag) {
                                                amtType = invParamRec.getPenaltyIntDesc().getValue();
                                            }
                                        }

                                        LineIdClass lineIdSet = new LineIdClass();

                                        // Condition to set lineset for property
                                        // not
                                        // in defined PARAM
                                        if ((!accPropFlag) && (!prinIntPropFlag) && (!penIntPropFlag)) {
                                            amtType = propertyName; // defaulting
                                                                    // prop
                                                                    // name, as
                                                                    // no desc
                                                                    // in
                                                                    // PARAM
                                                                    // table
                                        }
                                        lineIdSet.setLineId(String.valueOf(linereorderSize));
                                        lineIdSet.setAmount(orPropAmt);
                                        lineIdSet.setAmountType(amtType);
                                        lineIdSet.setBillId(billPresent);

                                        arrRec.addLineId(lineIdSet);

                                        // new end
                                        if (!orPropAmt.isEmpty()) {
                                            double newPropAmt1 = Double.parseDouble(orPropAmt);
                                            amtAdd = Double.sum(amtAdd, newPropAmt1);
                                        }
                                        linereorderSize++;
                                        linereorderSizeCnt++;
                                    } // present prop loop
                                } // present bill loop
                                double newTotAmtAll = 0;
                                newTotAmtAll = Double.sum(newTotAmt, amtAdd);
                                invDetailsRec.setArrangementId(arrRec, arrSize);
                                invDetailsRec.setTotalAmount(String.valueOf(df.format(newTotAmtAll)));
                            } // same arr check
 
                            arrSize++;
                        } // arr loop
                    } // else loop

                    TransactionData trans = new TransactionData();
     
                    trans.setFunction("INPUT");
                    trans.setNumberOfAuthoriser("0");
                    trans.setSourceId("HUS.LOAN");
                    trans.setVersionId(INVDETAILSVERSION);
                    trans.setTransactionId(hbInvoiceDetstypeId);
                    transactionData.add(trans);
                    transactionRecord.add(invDetailsRec.toStructure());
                } // invlist loop

                // Logic to remove reversed bills

            } catch (Exception e) {
                // TODO Auto-generated catch block
            }

        } // Auth status
    }
}
